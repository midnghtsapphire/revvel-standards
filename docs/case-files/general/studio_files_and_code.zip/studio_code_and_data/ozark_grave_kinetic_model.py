#!/usr/bin/env python3
"""
Ozark Soil Nitrogen & Dynamic pH Kinetic Model (LINDEMAN-2026-MO)
==================================================================
Simulates soil nitrogen transformation pathways (Organic N -> NH4+ -> NO3-)
and dynamic pH shifts in Ozark chert/silt soil matrices.
"""

import numpy as np

def simulate_ozark_grave_chemistry(days=40, temp=20.0, wfps=0.65, chert_pct=0.35):
    """
    Executes Forward Euler integration for decomposition kinetics in Ozark soil.
    
    Parameters:
    - days (float): Total simulation duration (days). Default: 40.0
    - temp (float): Average soil temperature (°C). Default: 20.0
    - wfps (float): Water-filled pore space (0.0 - 1.0). Default: 0.65
    - chert_pct (float): Fraction of chert gravel skeleton (0.0 - 1.0). Default: 0.35
    
    Returns:
    - time (ndarray): Time steps (days)
    - N_org (ndarray): Organic Nitrogen concentration (mg/kg or ppm)
    - NH4 (ndarray): Ammonium concentration (mg/kg or ppm)
    - NO3 (ndarray): Nitrate concentration (mg/kg or ppm)
    - pH_array (ndarray): Dynamic soil pH values
    """
    dt = 0.1
    steps = int(days / dt)
    time = np.linspace(0, days, steps)
    
    N_org = np.zeros(steps)
    NH4 = np.zeros(steps)
    NO3 = np.zeros(steps)
    pH_array = np.zeros(steps)
    
    N_org[0] = 500.0  # Initial protein/blood nitrogen input (ppm)
    NH4[0] = 10.0     # Baseline soil ammonium (ppm)
    NO3[0] = 15.0     # Baseline soil nitrate (ppm)
    
    base_pH = 5.2     # Native Ozark soil acidic baseline
    
    k_am = 0.4        # Ammonification rate constant (day^-1)
    k_ni = 0.08       # Nitrification rate constant (day^-1)
    
    f_T = np.exp(0.07 * (temp - 20.0)) if temp > 0 else 0.0
    
    if wfps < 0.60:
        f_theta_ni = wfps / 0.60
    elif 0.60 <= wfps <= 0.75:
        f_theta_ni = 1.0
    else:
        f_theta_ni = max(0.0, (1.0 - wfps) / 0.25)
        
    k_leach = 0.02 * (1.0 + chert_pct) if wfps > 0.70 else 0.005
    
    for i in range(steps - 1):
        current_pH = base_pH + min(2.8, 0.05 * NH4[i])
        pH_array[i] = current_pH
        
        f_pH = max(0.05, 1.0 - 0.05 * (7.5 - current_pH)**2) if current_pH < 7.5 else 1.0
        
        eff_k_am = k_am * f_T
        eff_k_ni = k_ni * f_T * f_pH * f_theta_ni
        
        dN_org = -eff_k_am * N_org[i]
        dNH4 = (eff_k_am * N_org[i]) - (eff_k_ni * NH4[i])
        dNO3 = (eff_k_ni * NH4[i]) - (k_leach * NO3[i])
        
        N_org[i+1] = N_org[i] + dN_org * dt
        NH4[i+1] = NH4[i] + dNH4 * dt
        NO3[i+1] = NO3[i] + dNO3 * dt
        
    pH_array[-1] = pH_array[-2]
    return time, N_org, NH4, NO3, pH_array

if __name__ == "__main__":
    t, n_org, nh4, no3, ph = simulate_ozark_grave_chemistry(days=40, temp=20.0, wfps=0.65, chert_pct=0.35)
    print(f"Simulation execution complete. Final Nitrate (Day 40): {no3[-1]:.2f} ppm | Final pH: {ph[-1]:.2f}")
