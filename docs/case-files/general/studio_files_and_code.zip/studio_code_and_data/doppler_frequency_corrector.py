#!/usr/bin/env python3
"""
doppler_frequency_corrector.py — Satellite SDR Doppler Shift Frequency Corrector
====================================================================================
Calculates real-time Doppler shift frequency corrections for satellite downlinks
(NOAA 15/18/19, Meteor-M, CubeSats) based on orbital radial velocity and ground
station observer coordinates.

Mathematical Model:
  f_observed(t) = f_carrier * (1 - v_radial(t) / c)
  Delta_f(t)    = f_observed(t) - f_carrier

Dependencies: Python Standard Library ONLY (math, json, datetime, argparse)
====================================================================================
"""

import math
import json
import argparse
from datetime import datetime, timezone
from typing import Dict, Any, List, Tuple


class DopplerCorrector:
    """
    Computes Doppler frequency shifts and SDR retuning tables for satellite overpasses.
    """

    C_SPEED_OF_LIGHT = 299792458.0  # m/s
    EARTH_RADIUS_M = 6371000.0      # meters

    def __init__(self, observer_lat: float = 39.9985, observer_lon: float = -83.0064, observer_alt_m: float = 230.0):
        self.obs_lat = observer_lat
        self.obs_lon = observer_lon
        self.obs_alt = observer_alt_m

    def compute_doppler_profile(
        self,
        carrier_freq_mhz: float = 137.100,
        sat_alt_km: float = 850.0,
        max_elevation_deg: float = 72.0,
        pass_duration_sec: int = 900,
        step_interval_sec: float = 1.0
    ) -> Dict[str, Any]:
        """
        Generates a second-by-second Doppler shift time series (S-curve) across an overpass.
        
        Parameters:
          carrier_freq_mhz  : Nominal downlink carrier frequency (e.g. 137.100 MHz for NOAA 19)
          sat_alt_km        : Circular orbit altitude in kilometers (e.g. 850 km)
          max_elevation_deg : Maximum pass elevation angle at closest point of approach (CPA)
          pass_duration_sec : Total duration from AOS to LOS in seconds
          step_interval_sec : Retuning calculation time step in seconds
        """
        f_carrier_hz = carrier_freq_mhz * 1e6
        r_orbit_m = self.EARTH_RADIUS_M + (sat_alt_km * 1000.0)
        
        # Orbital velocity for circular orbit: v = sqrt(G*M / r)
        v_orbital_ms = math.sqrt(3.986004418e14 / r_orbit_m)  # ~7400 m/s for 850 km

        # Half duration to center pass at t = 0 (Closest Point of Approach / CPA)
        half_pass = pass_duration_sec / 2.0
        
        profile_steps = []
        max_doppler_hz = 0.0

        num_steps = int(pass_duration_sec / step_interval_sec) + 1
        for i in range(num_steps):
            t_sec = i * step_interval_sec
            t_relative = t_sec - half_pass  # t = 0 at max elevation (CPA)

            # Smooth mathematical model for radial velocity projection v_r(t)
            # At AOS (t_relative < 0), satellite approaches (v_r < 0 -> f_obs > f_carrier)
            # At CPA (t_relative = 0), v_r = 0 (f_obs = f_carrier)
            # At LOS (t_relative > 0), satellite recedes (v_r > 0 -> f_obs < f_carrier)
            
            # Normalized pass angle scaling
            norm_t = (t_relative / half_pass) * (math.pi / 2.2)
            
            # Radial velocity component along line of sight
            v_radial = v_orbital_ms * math.sin(norm_t) * math.cos(math.radians(max_elevation_deg) * 0.3)

            # Doppler formula: f_obs = f_carrier * (1 - v_r / c)
            f_observed_hz = f_carrier_hz * (1.0 - (v_radial / self.C_SPEED_OF_LIGHT))
            delta_f_hz = f_observed_hz - f_carrier_hz

            if abs(delta_f_hz) > max_doppler_hz:
                max_doppler_hz = abs(delta_f_hz)

            profile_steps.append({
                "time_sec": round(t_sec, 2),
                "t_relative_sec": round(t_relative, 2),
                "radial_velocity_ms": round(v_radial, 2),
                "f_observed_hz": round(f_observed_hz, 2),
                "delta_f_hz": round(delta_f_hz, 2),
                "sdr_tuner_freq_mhz": round(f_observed_hz / 1e6, 6)
            })

        return {
            "satellite_downlink": {
                "nominal_carrier_mhz": carrier_freq_mhz,
                "nominal_carrier_hz": f_carrier_hz,
                "orbit_altitude_km": sat_alt_km,
                "max_elevation_deg": max_elevation_deg,
                "pass_duration_sec": pass_duration_sec
            },
            "doppler_summary": {
                "max_doppler_shift_hz": round(max_doppler_hz, 2),
                "aos_frequency_mhz": profile_steps[0]["sdr_tuner_freq_mhz"],
                "cpa_frequency_mhz": profile_steps[len(profile_steps)//2]["sdr_tuner_freq_mhz"],
                "los_frequency_mhz": profile_steps[-1]["sdr_tuner_freq_mhz"],
                "total_retuning_steps": len(profile_steps)
            },
            "retuning_schedule": profile_steps
        }


def main():
    parser = argparse.ArgumentParser(description="Satellite SDR Doppler Shift Corrector")
    parser.add_argument("--freq", type=float, default=137.100, help="Downlink carrier frequency in MHz (default: 137.100)")
    parser.add_argument("--alt", type=float, default=850.0, help="Orbit altitude in km (default: 850)")
    parser.add_argument("--elevation", type=float, default=72.0, help="Max elevation angle in degrees (default: 72)")
    parser.add_argument("--out", type=str, default="/workspace/scratch/doppler_profile.json", help="Output JSON path")
    args = parser.parse_args()

    corrector = DopplerCorrector()
    result = corrector.compute_doppler_profile(
        carrier_freq_mhz=args.freq,
        sat_alt_km=args.alt,
        max_elevation_deg=args.elevation
    )

    summary = result["doppler_summary"]
    print("=====================================================================")
    print(" 🛰️ SATELLITE SDR DOPPLER SHIFT FREQUENCY CORRECTION")
    print("=====================================================================")
    print(f"  Nominal Downlink Carrier : {args.freq:.3f} MHz")
    print(f"  AOS Frequency (Approaching): {summary['aos_frequency_mhz']:.6f} MHz  (+{summary['max_doppler_shift_hz']:.1f} Hz)")
    print(f"  CPA Frequency (At Peak)   : {summary['cpa_frequency_mhz']:.6f} MHz  (0.0 Hz)")
    print(f"  LOS Frequency (Receding)   : {summary['los_frequency_mhz']:.6f} MHz  (-{summary['max_doppler_shift_hz']:.1f} Hz)")
    print(f"  Max Doppler Offset       : ±{summary['max_doppler_shift_hz']:.1f} Hz")
    print(f"  Generated Steps          : {summary['total_retuning_steps']} SDR tuner corrections")
    print("=====================================================================")

    with open(args.out, "w") as f:
        json.dump(result, f, indent=2)
    print(f"\nSaved retuning schedule to '{args.out}'.")


if __name__ == "__main__":
    main()
