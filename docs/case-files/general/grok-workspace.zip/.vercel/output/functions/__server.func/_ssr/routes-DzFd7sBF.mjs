import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DzFd7sBF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function peelShellsWasm(scalar, n) {
	try {
		const res = await fetch("/peel.wasm");
		if (!res.ok) return null;
		const { instance } = await WebAssembly.instantiate(await res.arrayBuffer());
		const exp = instance.exports;
		const len = scalar.length;
		const scalarPtr = exp.alloc(len);
		const outPtr = exp.alloc(len);
		new Uint8Array(exp.memory.buffer, scalarPtr, len).set(scalar);
		exp.peel_shells(scalarPtr, n, outPtr);
		const out = new Uint8Array(len);
		out.set(new Uint8Array(exp.memory.buffer, outPtr, len));
		return out;
	} catch {
		return null;
	}
}
function hash(x, y, z) {
	let n = Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(z, 1274126177);
	n = Math.imul(n ^ n >>> 13, 1274126177);
	return ((n ^ n >>> 16) >>> 0) / 4294967295;
}
function idx(x, y, z) {
	return x + 48 * (y + 48 * z);
}
function buildVolume() {
	const scalar = /* @__PURE__ */ new Uint8Array(110592);
	const occ = /* @__PURE__ */ new Uint8Array(110592);
	const roots = [];
	for (let k = 0; k < 3; k++) for (let t = 0; t < 64; t++) {
		const a = t / 64 * Math.PI * 2 + k * 2.1;
		roots.push([
			Math.cos(a) * (.42 + k * .06),
			Math.sin(a * 2 + k) * .28,
			Math.sin(a) * (.4 + k * .04)
		]);
	}
	for (let z = 0; z < 48; z++) for (let y = 0; y < 48; y++) for (let x = 0; x < 48; x++) {
		const px = (x + .5) / 48 * 2 - 1;
		const py = (y + .5) / 48 * 2 - 1;
		const pz = (z + .5) / 48 * 2 - 1;
		const e = (px / .78) ** 2 + (py / .66) ** 2 + (pz / .74) ** 2;
		if (e > 1) continue;
		const i = idx(x, y, z);
		occ[i] = 1;
		let v = 48 + hash(x, y, z) * 36;
		let best = 1;
		for (const [rx, ry, rz] of roots) {
			const d = (px - rx) ** 2 + (py - ry) ** 2 + (pz - rz) ** 2;
			if (d < best) best = d;
		}
		if (best < .012 && e > .35) v = Math.max(v, 158);
		if ((px - .16) ** 2 + (py + .06) ** 2 + (pz - .04) ** 2 < .012) v = 228;
		scalar[i] = Math.min(255, v);
	}
	const shell = /* @__PURE__ */ new Uint8Array(110592);
	let cur = occ.slice();
	for (let s = 1; s <= 10; s++) {
		const next = cur.slice();
		for (let z = 0; z < 48; z++) for (let y = 0; y < 48; y++) for (let x = 0; x < 48; x++) {
			const i = idx(x, y, z);
			if (!cur[i]) continue;
			let edge = false;
			for (const [dx, dy, dz] of [
				[
					1,
					0,
					0
				],
				[
					-1,
					0,
					0
				],
				[
					0,
					1,
					0
				],
				[
					0,
					-1,
					0
				],
				[
					0,
					0,
					1
				],
				[
					0,
					0,
					-1
				]
			]) {
				const nx = x + dx;
				const ny = y + dy;
				const nz = z + dz;
				if (nx < 0 || ny < 0 || nz < 0 || nx >= 48 || ny >= 48 || nz >= 48 || !cur[idx(nx, ny, nz)]) {
					edge = true;
					break;
				}
			}
			if (edge) {
				shell[i] = s;
				next[i] = 0;
			}
		}
		cur = next;
	}
	for (let i = 0; i < cur.length; i++) if (cur[i]) shell[i] = 11;
	return {
		scalar,
		shell,
		size: 48
	};
}
function countHighlighted(vol, peel, thresh) {
	const cut = Math.round(thresh * 255);
	let highlighted = 0;
	let remaining = 0;
	for (let i = 0; i < vol.scalar.length; i++) {
		if (vol.shell[i] === 0) continue;
		if (vol.shell[i] <= peel) continue;
		remaining++;
		if (vol.scalar[i] >= cut) highlighted++;
	}
	return {
		highlighted,
		remaining
	};
}
var VERT = `#version 300 es
layout(location=0) in vec2 a;
void main() { gl_Position = vec4(a, 0.0, 1.0); }
`;
var FRAG = `#version 300 es
precision highp float;
precision highp sampler3D;
uniform sampler3D uVol;
uniform vec2 uRes;
uniform vec3 uCam;
uniform float uPeel;
uniform float uThresh;
uniform float uAr;
out vec4 fragColor;

vec2 box(vec3 ro, vec3 rd) {
  vec3 ird = 1.0 / rd;
  vec3 t0 = (vec3(-0.5) - ro) * ird;
  vec3 t1 = (vec3(0.5) - ro) * ird;
  vec3 tmin = min(t0, t1);
  vec3 tmax = max(t0, t1);
  float tn = max(max(tmin.x, tmin.y), tmin.z);
  float tf = min(min(tmax.x, tmax.y), tmax.z);
  return vec2(tn, tf);
}

void main() {
  vec2 uv = (gl_FragCoord.xy / uRes) * 2.0 - 1.0;
  uv.x *= uRes.x / uRes.y;
  vec3 forward = normalize(-uCam);
  vec3 right = normalize(cross(forward, vec3(0.0, 1.0, 0.0)));
  vec3 up = cross(right, forward);
  vec3 rd = normalize(forward + right * uv.x * 0.55 + up * uv.y * 0.55);
  vec3 ro = uCam;
  if (abs(rd.x) < 1e-5) rd.x = 1e-5;
  if (abs(rd.y) < 1e-5) rd.y = 1e-5;
  if (abs(rd.z) < 1e-5) rd.z = 1e-5;
  vec2 th = box(ro, rd);
  vec3 bg = vec3(0.047, 0.063, 0.078);
  if (th.x > th.y) {
    fragColor = uAr > 0.5 ? vec4(0.0) : vec4(bg, 1.0);
    return;
  }
  float t = max(th.x, 0.0);
  float dt = (th.y - t) / 80.0;
  vec4 acc = vec4(0.0);
  for (int i = 0; i < 80; i++) {
    vec3 p = ro + rd * (t + dt * 0.5);
    if (p.x < -0.5 || p.y < -0.5 || p.z < -0.5 || p.x > 0.5 || p.y > 0.5 || p.z > 0.5) {
      t += dt;
      continue;
    }
    vec2 sg = texture(uVol, p + 0.5).rg;
    float shell = sg.g * 12.0;
    float scalar = sg.r;
    t += dt;
    if (shell < 0.5 || shell <= uPeel) continue;
    if (scalar < 0.08) continue;
    vec3 col = vec3(0.55, 0.38, 0.22);
    float a = 0.045;
    if (scalar >= uThresh) {
      col = vec3(0.24, 0.86, 1.0);
      a = 0.62;
    }
    acc.rgb += (1.0 - acc.a) * col * a;
    acc.a += (1.0 - acc.a) * a;
    if (acc.a > 0.96) break;
  }
  fragColor = uAr > 0.5 ? vec4(acc.rgb, acc.a) : vec4(mix(bg, acc.rgb, acc.a), 1.0);
}
`;
function compile(gl, type, src) {
	const sh = gl.createShader(type);
	if (!sh) throw new Error("shader");
	gl.shaderSource(sh, src);
	gl.compileShader(sh);
	if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh) || "compile");
	return sh;
}
function VolumeView() {
	const canvasRef = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)({
		on: false,
		x: 0,
		y: 0,
		theta: .6,
		phi: 1.15
	});
	const [peel, setPeel] = (0, import_react.useState)(3);
	const [thresh, setThresh] = (0, import_react.useState)(.72);
	const [counts, setCounts] = (0, import_react.useState)({
		highlighted: 0,
		remaining: 0
	});
	const [webglError, setWebglError] = (0, import_react.useState)(null);
	const [engine, setEngine] = (0, import_react.useState)("…");
	const [camera, setCamera] = (0, import_react.useState)(false);
	const [camNote, setCamNote] = (0, import_react.useState)(null);
	const [vol, setVol] = (0, import_react.useState)(null);
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const watchRef = (0, import_react.useRef)(null);
	const [phone, setPhone] = (0, import_react.useState)(null);
	const uniforms = (0, import_react.useRef)({
		peel,
		thresh,
		ar: 0
	});
	uniforms.current = {
		peel,
		thresh,
		ar: camera ? 1 : 0
	};
	(0, import_react.useEffect)(() => {
		let cancel = false;
		const base = buildVolume();
		peelShellsWasm(base.scalar, base.size).then((shell) => {
			if (cancel) return;
			if (shell && shell.length === base.shell.length) {
				base.shell = shell;
				setEngine("WASM");
			} else setEngine("JS");
			setVol({ ...base });
		});
		return () => {
			cancel = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (vol) setCounts(countHighlighted(vol, peel, thresh));
	}, [
		vol,
		peel,
		thresh
	]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas || !vol) return;
		const gl = canvas.getContext("webgl2", {
			antialias: false,
			alpha: true,
			premultipliedAlpha: false
		});
		if (!gl) {
			setWebglError("This browser has no WebGL2. The counts on the right still update.");
			return;
		}
		const vs = compile(gl, gl.VERTEX_SHADER, VERT);
		const fs = compile(gl, gl.FRAGMENT_SHADER, FRAG);
		const prog = gl.createProgram();
		if (!prog) return;
		gl.attachShader(prog, vs);
		gl.attachShader(prog, fs);
		gl.linkProgram(prog);
		if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
			setWebglError(gl.getProgramInfoLog(prog) || "link");
			return;
		}
		gl.useProgram(prog);
		const buf = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, buf);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
			-1,
			-1,
			3,
			-1,
			-1,
			3
		]), gl.STATIC_DRAW);
		gl.enableVertexAttribArray(0);
		gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
		const tex = gl.createTexture();
		gl.activeTexture(gl.TEXTURE0);
		gl.bindTexture(gl.TEXTURE_3D, tex);
		const data = new Uint8Array(vol.size ** 3 * 2);
		for (let i = 0; i < vol.scalar.length; i++) {
			data[i * 2] = vol.scalar[i];
			data[i * 2 + 1] = Math.round(vol.shell[i] / 12 * 255);
		}
		gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
		gl.texImage3D(gl.TEXTURE_3D, 0, gl.RG8, vol.size, vol.size, vol.size, 0, gl.RG, gl.UNSIGNED_BYTE, data);
		gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_R, gl.CLAMP_TO_EDGE);
		const loc = {
			vol: gl.getUniformLocation(prog, "uVol"),
			res: gl.getUniformLocation(prog, "uRes"),
			cam: gl.getUniformLocation(prog, "uCam"),
			peel: gl.getUniformLocation(prog, "uPeel"),
			thresh: gl.getUniformLocation(prog, "uThresh"),
			ar: gl.getUniformLocation(prog, "uAr")
		};
		gl.uniform1i(loc.vol, 0);
		let frame = 0;
		let alive = true;
		const draw = () => {
			if (!alive) return;
			const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			if (!drag.current.on && !reduced && uniforms.current.ar < .5) drag.current.theta += .004;
			const { theta, phi } = drag.current;
			const r = 1.85;
			const cam = [
				r * Math.sin(phi) * Math.sin(theta),
				r * Math.cos(phi),
				r * Math.sin(phi) * Math.cos(theta)
			];
			const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
			const w = Math.max(1, canvas.clientWidth);
			const h = Math.max(1, canvas.clientHeight);
			const pw = Math.floor(w * dpr);
			const ph = Math.floor(h * dpr);
			if (canvas.width !== pw || canvas.height !== ph) {
				canvas.width = pw;
				canvas.height = ph;
			}
			gl.viewport(0, 0, canvas.width, canvas.height);
			gl.uniform2f(loc.res, canvas.width, canvas.height);
			gl.uniform3f(loc.cam, cam[0], cam[1], cam[2]);
			gl.uniform1f(loc.peel, uniforms.current.peel);
			gl.uniform1f(loc.thresh, uniforms.current.thresh);
			gl.uniform1f(loc.ar, uniforms.current.ar);
			gl.drawArrays(gl.TRIANGLES, 0, 3);
			frame = requestAnimationFrame(draw);
		};
		frame = requestAnimationFrame(draw);
		const pointer = (e) => {
			if (!drag.current.on) return;
			const dx = e.clientX - drag.current.x;
			const dy = e.clientY - drag.current.y;
			drag.current.x = e.clientX;
			drag.current.y = e.clientY;
			drag.current.theta -= dx * .01;
			drag.current.phi = Math.min(2.6, Math.max(.35, drag.current.phi + dy * .01));
		};
		const down = (e) => {
			drag.current.on = true;
			drag.current.x = e.clientX;
			drag.current.y = e.clientY;
			canvas.setPointerCapture(e.pointerId);
		};
		const up = () => {
			drag.current.on = false;
		};
		canvas.addEventListener("pointerdown", down);
		canvas.addEventListener("pointermove", pointer);
		canvas.addEventListener("pointerup", up);
		canvas.addEventListener("pointercancel", up);
		return () => {
			alive = false;
			cancelAnimationFrame(frame);
			canvas.removeEventListener("pointerdown", down);
			canvas.removeEventListener("pointermove", pointer);
			canvas.removeEventListener("pointerup", up);
			canvas.removeEventListener("pointercancel", up);
			gl.deleteTexture(tex);
			gl.deleteProgram(prog);
			gl.deleteShader(vs);
			gl.deleteShader(fs);
			gl.deleteBuffer(buf);
		};
	}, [vol]);
	(0, import_react.useEffect)(() => {
		const onOrient = (e) => {
			if (uniforms.current.ar < .5) return;
			const beta = e.beta ?? 0;
			const gamma = e.gamma ?? 0;
			drag.current.phi = Math.min(2.6, Math.max(.35, (beta + 20) * Math.PI / 180));
			drag.current.theta = gamma * Math.PI / 180;
		};
		window.addEventListener("deviceorientation", onOrient);
		return () => window.removeEventListener("deviceorientation", onOrient);
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			streamRef.current?.getTracks().forEach((track) => track.stop());
			if (watchRef.current != null) navigator.geolocation.clearWatch(watchRef.current);
		};
	}, []);
	function stopPhone() {
		if (watchRef.current != null) {
			navigator.geolocation.clearWatch(watchRef.current);
			watchRef.current = null;
		}
		setPhone(null);
	}
	function startPhone() {
		if (!navigator.geolocation) {
			setCamNote("This browser has no location. The volume stays unanchored.");
			return;
		}
		watchRef.current = navigator.geolocation.watchPosition((pos) => {
			setPhone({
				lat: pos.coords.latitude,
				lon: pos.coords.longitude,
				acc: pos.coords.accuracy
			});
		}, () => setCamNote("Location stayed off. The volume is not a map pin."), {
			enableHighAccuracy: true,
			maximumAge: 5e3
		});
	}
	async function toggleCamera() {
		if (camera) {
			streamRef.current?.getTracks().forEach((track) => track.stop());
			streamRef.current = null;
			if (videoRef.current) videoRef.current.srcObject = null;
			stopPhone();
			setCamera(false);
			return;
		}
		if (!navigator.mediaDevices?.getUserMedia) {
			setCamNote("This browser has no camera. Drag the volume instead.");
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({
				video: { facingMode: "environment" },
				audio: false
			});
			streamRef.current = stream;
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
				await videoRef.current.play();
			}
			const orientation = DeviceOrientationEvent;
			if (typeof orientation.requestPermission === "function") await orientation.requestPermission();
			setCamera(true);
			setCamNote(null);
			startPhone();
		} catch {
			setCamNote("Camera stayed off. The volume still works without it.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: camera ? "stage ar-live" : "stage",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: camera ? "viewport ar" : "viewport",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				className: "cam",
				playsInline: true,
				muted: true,
				autoPlay: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				"aria-label": "Simulated volume, drag to orbit"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "panel",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "field-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shells peeled" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: peel })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 0,
						max: 10,
						step: 1,
						value: peel,
						onChange: (e) => setPeel(Number(e.target.value))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "field-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Highlight above" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: thresh.toFixed(2) })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: .2,
						max: .95,
						step: .01,
						value: thresh,
						onChange: (e) => setThresh(Number(e.target.value))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "cam-btn",
					"aria-pressed": camera,
					onClick: toggleCamera,
					children: camera ? "Hide camera" : "Camera backdrop"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "stat",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Still in volume" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: counts.remaining.toLocaleString() })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Above threshold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: counts.highlighted.toLocaleString() })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: phone ? `${phone.lat.toFixed(4)}, ${phone.lon.toFixed(4)}` : "off" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Phone accuracy" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: phone ? `± ${Math.round(phone.acc)} m` : "—" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Peel engine" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: engine })] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "note",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Simulated." }), " Cyan is a value above the threshold, not a find. Phone coordinates are this device. The volume is not anchored to the ground."]
				}),
				camNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "note",
					children: camNote
				}) : null,
				webglError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "note",
					children: webglError
				}) : null
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "page",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "top",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Layer Peel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Drag the volume. The slider strips outer shells. The count is how many remaining voxels sit above the threshold." })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeView, {})]
	});
}
//#endregion
export { Home as component };
