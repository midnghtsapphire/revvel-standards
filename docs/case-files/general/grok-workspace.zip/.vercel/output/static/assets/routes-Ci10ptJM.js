import{n as e,r as t,t as n}from"./index-Du382v_q.js";var r=t(e(),1);async function i(e,t){try{let n=await fetch(`/peel.wasm`);if(!n.ok)return null;let{instance:r}=await WebAssembly.instantiate(await n.arrayBuffer()),i=r.exports,a=e.length,o=i.alloc(a),s=i.alloc(a);new Uint8Array(i.memory.buffer,o,a).set(e),i.peel_shells(o,t,s);let c=new Uint8Array(a);return c.set(new Uint8Array(i.memory.buffer,s,a)),c}catch{return null}}function a(e,t,n){let r=Math.imul(e,374761393)+Math.imul(t,668265263)+Math.imul(n,1274126177);return r=Math.imul(r^r>>>13,1274126177),((r^r>>>16)>>>0)/4294967295}function o(e,t,n){return e+48*(t+48*n)}function s(){let e=new Uint8Array(110592),t=new Uint8Array(110592),n=[];for(let e=0;e<3;e++)for(let t=0;t<64;t++){let r=t/64*Math.PI*2+e*2.1;n.push([Math.cos(r)*(.42+e*.06),Math.sin(r*2+e)*.28,Math.sin(r)*(.4+e*.04)])}for(let r=0;r<48;r++)for(let i=0;i<48;i++)for(let s=0;s<48;s++){let c=(s+.5)/48*2-1,l=(i+.5)/48*2-1,u=(r+.5)/48*2-1,d=(c/.78)**2+(l/.66)**2+(u/.74)**2;if(d>1)continue;let f=o(s,i,r);t[f]=1;let p=48+a(s,i,r)*36,m=1;for(let[e,t,r]of n){let n=(c-e)**2+(l-t)**2+(u-r)**2;n<m&&(m=n)}m<.012&&d>.35&&(p=Math.max(p,158)),(c-.16)**2+(l+.06)**2+(u-.04)**2<.012&&(p=228),e[f]=Math.min(255,p)}let r=new Uint8Array(110592),i=t.slice();for(let e=1;e<=10;e++){let t=i.slice();for(let n=0;n<48;n++)for(let a=0;a<48;a++)for(let s=0;s<48;s++){let c=o(s,a,n);if(!i[c])continue;let l=!1;for(let[e,t,r]of[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){let c=s+e,u=a+t,d=n+r;if(c<0||u<0||d<0||c>=48||u>=48||d>=48||!i[o(c,u,d)]){l=!0;break}}l&&(r[c]=e,t[c]=0)}i=t}for(let e=0;e<i.length;e++)i[e]&&(r[e]=11);return{scalar:e,shell:r,size:48}}function c(e,t,n){let r=Math.round(n*255),i=0,a=0;for(let n=0;n<e.scalar.length;n++)e.shell[n]!==0&&(e.shell[n]<=t||(a++,e.scalar[n]>=r&&i++));return{highlighted:i,remaining:a}}var l=n(),u=`#version 300 es
layout(location=0) in vec2 a;
void main() { gl_Position = vec4(a, 0.0, 1.0); }
`,d=`#version 300 es
precision highp float;
precision highp sampler3D;
uniform sampler3D uVol;
uniform vec2 uRes;
uniform vec3 uCam;
uniform float uPeel;
uniform float uThresh;
uniform float uAr;
out vec4 fragColor;

vec2 box(vec3 ro, vec3 rd) {
  vec3 ird = 1.0 / rd;
  vec3 t0 = (vec3(-0.5) - ro) * ird;
  vec3 t1 = (vec3(0.5) - ro) * ird;
  vec3 tmin = min(t0, t1);
  vec3 tmax = max(t0, t1);
  float tn = max(max(tmin.x, tmin.y), tmin.z);
  float tf = min(min(tmax.x, tmax.y), tmax.z);
  return vec2(tn, tf);
}

void main() {
  vec2 uv = (gl_FragCoord.xy / uRes) * 2.0 - 1.0;
  uv.x *= uRes.x / uRes.y;
  vec3 forward = normalize(-uCam);
  vec3 right = normalize(cross(forward, vec3(0.0, 1.0, 0.0)));
  vec3 up = cross(right, forward);
  vec3 rd = normalize(forward + right * uv.x * 0.55 + up * uv.y * 0.55);
  vec3 ro = uCam;
  if (abs(rd.x) < 1e-5) rd.x = 1e-5;
  if (abs(rd.y) < 1e-5) rd.y = 1e-5;
  if (abs(rd.z) < 1e-5) rd.z = 1e-5;
  vec2 th = box(ro, rd);
  vec3 bg = vec3(0.047, 0.063, 0.078);
  if (th.x > th.y) {
    fragColor = uAr > 0.5 ? vec4(0.0) : vec4(bg, 1.0);
    return;
  }
  float t = max(th.x, 0.0);
  float dt = (th.y - t) / 80.0;
  vec4 acc = vec4(0.0);
  for (int i = 0; i < 80; i++) {
    vec3 p = ro + rd * (t + dt * 0.5);
    if (p.x < -0.5 || p.y < -0.5 || p.z < -0.5 || p.x > 0.5 || p.y > 0.5 || p.z > 0.5) {
      t += dt;
      continue;
    }
    vec2 sg = texture(uVol, p + 0.5).rg;
    float shell = sg.g * 12.0;
    float scalar = sg.r;
    t += dt;
    if (shell < 0.5 || shell <= uPeel) continue;
    if (scalar < 0.08) continue;
    vec3 col = vec3(0.55, 0.38, 0.22);
    float a = 0.045;
    if (scalar >= uThresh) {
      col = vec3(0.24, 0.86, 1.0);
      a = 0.62;
    }
    acc.rgb += (1.0 - acc.a) * col * a;
    acc.a += (1.0 - acc.a) * a;
    if (acc.a > 0.96) break;
  }
  fragColor = uAr > 0.5 ? vec4(acc.rgb, acc.a) : vec4(mix(bg, acc.rgb, acc.a), 1.0);
}
`;function f(e,t,n){let r=e.createShader(t);if(!r)throw Error(`shader`);if(e.shaderSource(r,n),e.compileShader(r),!e.getShaderParameter(r,e.COMPILE_STATUS))throw Error(e.getShaderInfoLog(r)||`compile`);return r}function p(){let e=(0,r.useRef)(null),t=(0,r.useRef)({on:!1,x:0,y:0,theta:.6,phi:1.15}),[n,a]=(0,r.useState)(3),[o,p]=(0,r.useState)(.72),[m,h]=(0,r.useState)({highlighted:0,remaining:0}),[g,_]=(0,r.useState)(null),[v,y]=(0,r.useState)(`…`),[b,x]=(0,r.useState)(!1),[S,C]=(0,r.useState)(null),[w,T]=(0,r.useState)(null),E=(0,r.useRef)(null),D=(0,r.useRef)(null),O=(0,r.useRef)(null),[k,A]=(0,r.useState)(null),j=(0,r.useRef)({peel:n,thresh:o,ar:0});j.current={peel:n,thresh:o,ar:+!!b},(0,r.useEffect)(()=>{let e=!1,t=s();return i(t.scalar,t.size).then(n=>{e||(n&&n.length===t.shell.length?(t.shell=n,y(`WASM`)):y(`JS`),T({...t}))}),()=>{e=!0}},[]),(0,r.useEffect)(()=>{w&&h(c(w,n,o))},[w,n,o]),(0,r.useEffect)(()=>{let n=e.current;if(!n||!w)return;let r=n.getContext(`webgl2`,{antialias:!1,alpha:!0,premultipliedAlpha:!1});if(!r){_(`This browser has no WebGL2. The counts on the right still update.`);return}let i=f(r,r.VERTEX_SHADER,u),a=f(r,r.FRAGMENT_SHADER,d),o=r.createProgram();if(!o)return;if(r.attachShader(o,i),r.attachShader(o,a),r.linkProgram(o),!r.getProgramParameter(o,r.LINK_STATUS)){_(r.getProgramInfoLog(o)||`link`);return}r.useProgram(o);let s=r.createBuffer();r.bindBuffer(r.ARRAY_BUFFER,s),r.bufferData(r.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),r.STATIC_DRAW),r.enableVertexAttribArray(0),r.vertexAttribPointer(0,2,r.FLOAT,!1,0,0);let c=r.createTexture();r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_3D,c);let l=new Uint8Array(w.size**3*2);for(let e=0;e<w.scalar.length;e++)l[e*2]=w.scalar[e],l[e*2+1]=Math.round(w.shell[e]/12*255);r.pixelStorei(r.UNPACK_ALIGNMENT,1),r.texImage3D(r.TEXTURE_3D,0,r.RG8,w.size,w.size,w.size,0,r.RG,r.UNSIGNED_BYTE,l),r.texParameteri(r.TEXTURE_3D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_3D,r.TEXTURE_MAG_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_3D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_3D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_3D,r.TEXTURE_WRAP_R,r.CLAMP_TO_EDGE);let p={vol:r.getUniformLocation(o,`uVol`),res:r.getUniformLocation(o,`uRes`),cam:r.getUniformLocation(o,`uCam`),peel:r.getUniformLocation(o,`uPeel`),thresh:r.getUniformLocation(o,`uThresh`),ar:r.getUniformLocation(o,`uAr`)};r.uniform1i(p.vol,0);let m=0,h=!0,g=()=>{if(!h)return;let e=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches;!t.current.on&&!e&&j.current.ar<.5&&(t.current.theta+=.004);let{theta:i,phi:a}=t.current,o=1.85,s=[o*Math.sin(a)*Math.sin(i),o*Math.cos(a),o*Math.sin(a)*Math.cos(i)],c=Math.min(window.devicePixelRatio||1,1.5),l=Math.max(1,n.clientWidth),u=Math.max(1,n.clientHeight),d=Math.floor(l*c),f=Math.floor(u*c);(n.width!==d||n.height!==f)&&(n.width=d,n.height=f),r.viewport(0,0,n.width,n.height),r.uniform2f(p.res,n.width,n.height),r.uniform3f(p.cam,s[0],s[1],s[2]),r.uniform1f(p.peel,j.current.peel),r.uniform1f(p.thresh,j.current.thresh),r.uniform1f(p.ar,j.current.ar),r.drawArrays(r.TRIANGLES,0,3),m=requestAnimationFrame(g)};m=requestAnimationFrame(g);let v=e=>{if(!t.current.on)return;let n=e.clientX-t.current.x,r=e.clientY-t.current.y;t.current.x=e.clientX,t.current.y=e.clientY,t.current.theta-=n*.01,t.current.phi=Math.min(2.6,Math.max(.35,t.current.phi+r*.01))},y=e=>{t.current.on=!0,t.current.x=e.clientX,t.current.y=e.clientY,n.setPointerCapture(e.pointerId)},b=()=>{t.current.on=!1};return n.addEventListener(`pointerdown`,y),n.addEventListener(`pointermove`,v),n.addEventListener(`pointerup`,b),n.addEventListener(`pointercancel`,b),()=>{h=!1,cancelAnimationFrame(m),n.removeEventListener(`pointerdown`,y),n.removeEventListener(`pointermove`,v),n.removeEventListener(`pointerup`,b),n.removeEventListener(`pointercancel`,b),r.deleteTexture(c),r.deleteProgram(o),r.deleteShader(i),r.deleteShader(a),r.deleteBuffer(s)}},[w]),(0,r.useEffect)(()=>{let e=e=>{if(j.current.ar<.5)return;let n=e.beta??0,r=e.gamma??0;t.current.phi=Math.min(2.6,Math.max(.35,(n+20)*Math.PI/180)),t.current.theta=r*Math.PI/180};return window.addEventListener(`deviceorientation`,e),()=>window.removeEventListener(`deviceorientation`,e)},[]),(0,r.useEffect)(()=>()=>{D.current?.getTracks().forEach(e=>e.stop()),O.current!=null&&navigator.geolocation.clearWatch(O.current)},[]);function M(){O.current!=null&&(navigator.geolocation.clearWatch(O.current),O.current=null),A(null)}function N(){if(!navigator.geolocation){C(`This browser has no location. The volume stays unanchored.`);return}O.current=navigator.geolocation.watchPosition(e=>{A({lat:e.coords.latitude,lon:e.coords.longitude,acc:e.coords.accuracy})},()=>C(`Location stayed off. The volume is not a map pin.`),{enableHighAccuracy:!0,maximumAge:5e3})}async function P(){if(b){D.current?.getTracks().forEach(e=>e.stop()),D.current=null,E.current&&(E.current.srcObject=null),M(),x(!1);return}if(!navigator.mediaDevices?.getUserMedia){C(`This browser has no camera. Drag the volume instead.`);return}try{let e=await navigator.mediaDevices.getUserMedia({video:{facingMode:`environment`},audio:!1});D.current=e,E.current&&(E.current.srcObject=e,await E.current.play());let t=DeviceOrientationEvent;typeof t.requestPermission==`function`&&await t.requestPermission(),x(!0),C(null),N()}catch{C(`Camera stayed off. The volume still works without it.`)}}return(0,l.jsxs)(`div`,{className:b?`stage ar-live`:`stage`,children:[(0,l.jsxs)(`div`,{className:b?`viewport ar`:`viewport`,children:[(0,l.jsx)(`video`,{ref:E,className:`cam`,playsInline:!0,muted:!0,autoPlay:!0}),(0,l.jsx)(`canvas`,{ref:e,"aria-label":`Simulated volume, drag to orbit`})]}),(0,l.jsxs)(`aside`,{className:`panel`,children:[(0,l.jsxs)(`label`,{className:`field`,children:[(0,l.jsxs)(`span`,{className:`field-head`,children:[(0,l.jsx)(`span`,{children:`Shells peeled`}),(0,l.jsx)(`span`,{children:n})]}),(0,l.jsx)(`input`,{type:`range`,min:0,max:10,step:1,value:n,onChange:e=>a(Number(e.target.value))})]}),(0,l.jsxs)(`label`,{className:`field`,children:[(0,l.jsxs)(`span`,{className:`field-head`,children:[(0,l.jsx)(`span`,{children:`Highlight above`}),(0,l.jsx)(`span`,{children:o.toFixed(2)})]}),(0,l.jsx)(`input`,{type:`range`,min:.2,max:.95,step:.01,value:o,onChange:e=>p(Number(e.target.value))})]}),(0,l.jsx)(`button`,{type:`button`,className:`cam-btn`,"aria-pressed":b,onClick:P,children:b?`Hide camera`:`Camera backdrop`}),(0,l.jsxs)(`dl`,{className:`stat`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`dt`,{children:`Still in volume`}),(0,l.jsx)(`dd`,{children:m.remaining.toLocaleString()})]}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`dt`,{children:`Above threshold`}),(0,l.jsx)(`dd`,{children:m.highlighted.toLocaleString()})]}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`dt`,{children:`Phone`}),(0,l.jsx)(`dd`,{children:k?`${k.lat.toFixed(4)}, ${k.lon.toFixed(4)}`:`off`})]}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`dt`,{children:`Phone accuracy`}),(0,l.jsx)(`dd`,{children:k?`± ${Math.round(k.acc)} m`:`—`})]}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`dt`,{children:`Peel engine`}),(0,l.jsx)(`dd`,{children:v})]})]}),(0,l.jsxs)(`p`,{className:`note`,children:[(0,l.jsx)(`strong`,{children:`Simulated.`}),` Cyan is a value above the threshold, not a find. Phone coordinates are this device. The volume is not anchored to the ground.`]}),S?(0,l.jsx)(`p`,{className:`note`,children:S}):null,g?(0,l.jsx)(`p`,{className:`note`,children:g}):null]})]})}function m(){return(0,l.jsxs)(`main`,{className:`page`,children:[(0,l.jsxs)(`header`,{className:`top`,children:[(0,l.jsx)(`h1`,{children:`Layer Peel`}),(0,l.jsx)(`p`,{children:`Drag the volume. The slider strips outer shells. The count is how many remaining voxels sit above the threshold.`})]}),(0,l.jsx)(p,{})]})}export{m as component};