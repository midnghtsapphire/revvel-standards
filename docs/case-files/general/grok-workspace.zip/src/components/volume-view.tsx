import { useEffect, useRef, useState } from "react";
import { peelShellsWasm } from "@/lib/peel-wasm";
import { MAX_SHELL, MODEL_CONFIDENCE_CAP, buildVolume, countHighlighted, modelConfidence, type Volume } from "@/lib/volume";

const VERT = `#version 300 es
layout(location=0) in vec2 a;
void main() { gl_Position = vec4(a, 0.0, 1.0); }
`;

const FRAG = `#version 300 es
precision highp float;
precision highp sampler3D;
uniform sampler3D uVol;
uniform vec2 uRes;
uniform vec3 uCam;
uniform float uPeel;
uniform float uThresh;
uniform float uAr;
out vec4 fragColor;

vec2 box(vec3 ro, vec3 rd) {
  vec3 ird = 1.0 / rd;
  vec3 t0 = (vec3(-0.5) - ro) * ird;
  vec3 t1 = (vec3(0.5) - ro) * ird;
  vec3 tmin = min(t0, t1);
  vec3 tmax = max(t0, t1);
  float tn = max(max(tmin.x, tmin.y), tmin.z);
  float tf = min(min(tmax.x, tmax.y), tmax.z);
  return vec2(tn, tf);
}

void main() {
  vec2 uv = (gl_FragCoord.xy / uRes) * 2.0 - 1.0;
  uv.x *= uRes.x / uRes.y;
  vec3 forward = normalize(-uCam);
  vec3 right = normalize(cross(forward, vec3(0.0, 1.0, 0.0)));
  vec3 up = cross(right, forward);
  vec3 rd = normalize(forward + right * uv.x * 0.55 + up * uv.y * 0.55);
  vec3 ro = uCam;
  if (abs(rd.x) < 1e-5) rd.x = 1e-5;
  if (abs(rd.y) < 1e-5) rd.y = 1e-5;
  if (abs(rd.z) < 1e-5) rd.z = 1e-5;
  vec2 th = box(ro, rd);
  vec3 bg = vec3(0.047, 0.063, 0.078);
  if (th.x > th.y) {
    fragColor = uAr > 0.5 ? vec4(0.0) : vec4(bg, 1.0);
    return;
  }
  float t = max(th.x, 0.0);
  float dt = (th.y - t) / 80.0;
  vec4 acc = vec4(0.0);
  for (int i = 0; i < 80; i++) {
    vec3 p = ro + rd * (t + dt * 0.5);
    if (p.x < -0.5 || p.y < -0.5 || p.z < -0.5 || p.x > 0.5 || p.y > 0.5 || p.z > 0.5) {
      t += dt;
      continue;
    }
    vec2 sg = texture(uVol, p + 0.5).rg;
    float shell = sg.g * 12.0;
    float scalar = sg.r;
    t += dt;
    if (shell < 0.5 || shell <= uPeel) continue;
    if (scalar < 0.08) continue;
    vec3 col = vec3(0.55, 0.38, 0.22);
    float a = 0.045;
    if (scalar >= uThresh) {
      col = vec3(0.24, 0.86, 1.0);
      a = 0.62;
    }
    acc.rgb += (1.0 - acc.a) * col * a;
    acc.a += (1.0 - acc.a) * a;
    if (acc.a > 0.96) break;
  }
  fragColor = uAr > 0.5 ? vec4(acc.rgb, acc.a) : vec4(mix(bg, acc.rgb, acc.a), 1.0);
}
`;

function compile(gl: WebGL2RenderingContext, type: number, src: string) {
  const sh = gl.createShader(type);
  if (!sh) throw new Error("shader");
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    throw new Error(gl.getShaderInfoLog(sh) || "compile");
  }
  return sh;
}

export function VolumeView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drag = useRef({ on: false, x: 0, y: 0, theta: 0.6, phi: 1.15 });
  const [peel, setPeel] = useState(3);
  const [thresh, setThresh] = useState(0.72);
  const [counts, setCounts] = useState({ highlighted: 0, remaining: 0 });
  const [webglError, setWebglError] = useState<string | null>(null);
  const [engine, setEngine] = useState("…");
  const [camera, setCamera] = useState(false);
  const [camNote, setCamNote] = useState<string | null>(null);
  const [vol, setVol] = useState<Volume | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const watchRef = useRef<number | null>(null);
  const [phone, setPhone] = useState<{ lat: number; lon: number; acc: number } | null>(null);
  const uniforms = useRef({ peel, thresh, ar: 0 });
  uniforms.current = { peel, thresh, ar: camera ? 1 : 0 };

  useEffect(() => {
    let cancel = false;
    const base = buildVolume();
    peelShellsWasm(base.scalar, base.size).then((shell) => {
      if (cancel) return;
      if (shell && shell.length === base.shell.length) {
        base.shell = shell;
        setEngine("WASM");
      } else {
        setEngine("JS");
      }
      setVol({ ...base });
    });
    return () => {
      cancel = true;
    };
  }, []);

  useEffect(() => {
    if (vol) setCounts(countHighlighted(vol, peel, thresh));
  }, [vol, peel, thresh]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !vol) return;
    const gl = canvas.getContext("webgl2", { antialias: false, alpha: true, premultipliedAlpha: false });
    if (!gl) {
      setWebglError("This browser has no WebGL2. The counts on the right still update.");
      return;
    }
    const vs = compile(gl, gl.VERTEX_SHADER, VERT);
    const fs = compile(gl, gl.FRAGMENT_SHADER, FRAG);
    const prog = gl.createProgram();
    if (!prog) return;
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      setWebglError(gl.getProgramInfoLog(prog) || "link");
      return;
    }
    gl.useProgram(prog);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

    const tex = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_3D, tex);
    const data = new Uint8Array(vol.size ** 3 * 2);
    for (let i = 0; i < vol.scalar.length; i++) {
      data[i * 2] = vol.scalar[i];
      data[i * 2 + 1] = Math.round((vol.shell[i] / 12) * 255);
    }
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.texImage3D(gl.TEXTURE_3D, 0, gl.RG8, vol.size, vol.size, vol.size, 0, gl.RG, gl.UNSIGNED_BYTE, data);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_R, gl.CLAMP_TO_EDGE);

    const loc = {
      vol: gl.getUniformLocation(prog, "uVol"),
      res: gl.getUniformLocation(prog, "uRes"),
      cam: gl.getUniformLocation(prog, "uCam"),
      peel: gl.getUniformLocation(prog, "uPeel"),
      thresh: gl.getUniformLocation(prog, "uThresh"),
      ar: gl.getUniformLocation(prog, "uAr"),
    };
    gl.uniform1i(loc.vol, 0);

    let frame = 0;
    let alive = true;
    const draw = () => {
      if (!alive) return;
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!drag.current.on && !reduced && uniforms.current.ar < 0.5) drag.current.theta += 0.004;
      const { theta, phi } = drag.current;
      const r = 1.85;
      const cam = [
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi),
        r * Math.sin(phi) * Math.cos(theta),
      ];
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const w = Math.max(1, canvas.clientWidth);
      const h = Math.max(1, canvas.clientHeight);
      const pw = Math.floor(w * dpr);
      const ph = Math.floor(h * dpr);
      if (canvas.width !== pw || canvas.height !== ph) {
        canvas.width = pw;
        canvas.height = ph;
      }
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.uniform2f(loc.res, canvas.width, canvas.height);
      gl.uniform3f(loc.cam, cam[0], cam[1], cam[2]);
      gl.uniform1f(loc.peel, uniforms.current.peel);
      gl.uniform1f(loc.thresh, uniforms.current.thresh);
      gl.uniform1f(loc.ar, uniforms.current.ar);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);

    const pointer = (e: PointerEvent) => {
      if (!drag.current.on) return;
      const dx = e.clientX - drag.current.x;
      const dy = e.clientY - drag.current.y;
      drag.current.x = e.clientX;
      drag.current.y = e.clientY;
      drag.current.theta -= dx * 0.01;
      drag.current.phi = Math.min(2.6, Math.max(0.35, drag.current.phi + dy * 0.01));
    };
    const down = (e: PointerEvent) => {
      drag.current.on = true;
      drag.current.x = e.clientX;
      drag.current.y = e.clientY;
      canvas.setPointerCapture(e.pointerId);
    };
    const up = () => {
      drag.current.on = false;
    };
    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", pointer);
    canvas.addEventListener("pointerup", up);
    canvas.addEventListener("pointercancel", up);

    return () => {
      alive = false;
      cancelAnimationFrame(frame);
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", pointer);
      canvas.removeEventListener("pointerup", up);
      canvas.removeEventListener("pointercancel", up);
      gl.deleteTexture(tex);
      gl.deleteProgram(prog);
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      gl.deleteBuffer(buf);
    };
  }, [vol]);

  useEffect(() => {
    const onOrient = (e: DeviceOrientationEvent) => {
      if (uniforms.current.ar < 0.5) return;
      const beta = e.beta ?? 0;
      const gamma = e.gamma ?? 0;
      drag.current.phi = Math.min(2.6, Math.max(0.35, ((beta + 20) * Math.PI) / 180));
      drag.current.theta = (gamma * Math.PI) / 180;
    };
    window.addEventListener("deviceorientation", onOrient);
    return () => window.removeEventListener("deviceorientation", onOrient);
  }, []);

  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((track) => track.stop());
      if (watchRef.current != null) navigator.geolocation.clearWatch(watchRef.current);
    };
  }, []);

  function stopPhone() {
    if (watchRef.current != null) {
      navigator.geolocation.clearWatch(watchRef.current);
      watchRef.current = null;
    }
    setPhone(null);
  }

  function startPhone() {
    if (!navigator.geolocation) {
      setCamNote("This browser has no location. The volume stays unanchored.");
      return;
    }
    watchRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        setPhone({
          lat: pos.coords.latitude,
          lon: pos.coords.longitude,
          acc: pos.coords.accuracy,
        });
      },
      () => setCamNote("Location stayed off. The volume is not a map pin."),
      { enableHighAccuracy: true, maximumAge: 5000 },
    );
  }

  async function toggleCamera() {
    if (camera) {
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      if (videoRef.current) videoRef.current.srcObject = null;
      stopPhone();
      setCamera(false);
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setCamNote("This browser has no camera. Drag the volume instead.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      const orientation = DeviceOrientationEvent as unknown as {
        requestPermission?: () => Promise<string>;
      };
      if (typeof orientation.requestPermission === "function") {
        await orientation.requestPermission();
      }
      setCamera(true);
      setCamNote(null);
      startPhone();
    } catch {
      setCamNote("Camera stayed off. The volume still works without it.");
    }
  }

  const confidence = modelConfidence(counts);

  return (
    <div className={camera ? "stage ar-live" : "stage"}>
      <div className={camera ? "viewport ar" : "viewport"}>
        <video ref={videoRef} className="cam" playsInline muted autoPlay />
        <canvas ref={canvasRef} aria-label="Simulated volume, drag to orbit" />
      </div>
      <aside className="panel">
        <label className="field">
          <span className="field-head">
            <span>Shells peeled</span>
            <span>{peel}</span>
          </span>
          <input
            type="range"
            min={0}
            max={MAX_SHELL}
            step={1}
            value={peel}
            onChange={(e) => setPeel(Number(e.target.value))}
          />
        </label>
        <label className="field">
          <span className="field-head">
            <span>Highlight above</span>
            <span>{thresh.toFixed(2)}</span>
          </span>
          <input
            type="range"
            min={0.2}
            max={0.95}
            step={0.01}
            value={thresh}
            onChange={(e) => setThresh(Number(e.target.value))}
          />
        </label>
        <button type="button" className="cam-btn" aria-pressed={camera} onClick={toggleCamera}>
          {camera ? "Hide camera" : "Camera backdrop"}
        </button>
        <div className="meter">
          <div className="field-head">
            <span>Model confidence</span>
            <span>{confidence.toFixed(2)}</span>
          </div>
          <div
            className="meter-track"
            role="img"
            aria-label={`Model confidence ${confidence.toFixed(2)} out of 1. Capped at ${MODEL_CONFIDENCE_CAP} because this grid is simulated.`}
          >
            <div className="meter-fill" style={{ width: `${confidence * 100}%` }} />
            <div className="meter-cap" style={{ left: `${MODEL_CONFIDENCE_CAP * 100}%` }} />
          </div>
          <p className="scale-key">0 none · 0.2 model · 0.4 public map · 0.6 one scan · 0.8 repeated scan · 1 identified</p>
        </div>
        <dl className="stat">
          <div>
            <dt>Still in volume</dt>
            <dd>{counts.remaining.toLocaleString()}</dd>
          </div>
          <div>
            <dt>Above threshold</dt>
            <dd>{counts.highlighted.toLocaleString()}</dd>
          </div>
          <div>
            <dt>Phone</dt>
            <dd>{phone ? `${phone.lat.toFixed(4)}, ${phone.lon.toFixed(4)}` : "off"}</dd>
          </div>
          <div>
            <dt>Phone accuracy</dt>
            <dd>{phone ? `± ${Math.round(phone.acc)} m` : "—"}</dd>
          </div>
          <div>
            <dt>Peel engine</dt>
            <dd>{engine}</dd>
          </div>
        </dl>
        <p className="note">
          <strong>Simulated.</strong> The score cannot pass 0.2 until a real instrument is attached. Cyan is not a find.
        </p>
        {camNote ? <p className="note">{camNote}</p> : null}
        {webglError ? <p className="note">{webglError}</p> : null}
      </aside>
    </div>
  );
}
