import { createFileRoute } from "@tanstack/react-router";
import { VolumeView } from "@/components/volume-view";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="page">
      <header className="top">
        <h1>Layer Peel</h1>
        <p>
          Drag the volume. The slider strips outer shells. The count is how many remaining voxels sit
          above the threshold.
        </p>
      </header>
      <VolumeView />
    </main>
  );
}
