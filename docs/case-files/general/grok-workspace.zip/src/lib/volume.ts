export const N = 48;
export const MAX_SHELL = 10;

export type Volume = {
  scalar: Uint8Array;
  shell: Uint8Array;
  size: number;
};

function hash(x: number, y: number, z: number) {
  let n = Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(z, 1274126177);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}

function idx(x: number, y: number, z: number) {
  return x + N * (y + N * z);
}

export function buildVolume(): Volume {
  const scalar = new Uint8Array(N * N * N);
  const occ = new Uint8Array(N * N * N);

  const roots: Array<[number, number, number]> = [];
  for (let k = 0; k < 3; k++) {
    for (let t = 0; t < 64; t++) {
      const a = (t / 64) * Math.PI * 2 + k * 2.1;
      roots.push([
        Math.cos(a) * (0.42 + k * 0.06),
        Math.sin(a * 2 + k) * 0.28,
        Math.sin(a) * (0.4 + k * 0.04),
      ]);
    }
  }

  for (let z = 0; z < N; z++) {
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        const px = ((x + 0.5) / N) * 2 - 1;
        const py = ((y + 0.5) / N) * 2 - 1;
        const pz = ((z + 0.5) / N) * 2 - 1;
        const e = (px / 0.78) ** 2 + (py / 0.66) ** 2 + (pz / 0.74) ** 2;
        if (e > 1) continue;
        const i = idx(x, y, z);
        occ[i] = 1;
        let v = 48 + hash(x, y, z) * 36;
        let best = 1;
        for (const [rx, ry, rz] of roots) {
          const d = (px - rx) ** 2 + (py - ry) ** 2 + (pz - rz) ** 2;
          if (d < best) best = d;
        }
        if (best < 0.012 && e > 0.35) v = Math.max(v, 158);
        const ad = (px - 0.16) ** 2 + (py + 0.06) ** 2 + (pz - 0.04) ** 2;
        if (ad < 0.012) v = 228;
        scalar[i] = Math.min(255, v);
      }
    }
  }

  const shell = new Uint8Array(N * N * N);
  let cur = occ.slice();
  for (let s = 1; s <= MAX_SHELL; s++) {
    const next = cur.slice();
    for (let z = 0; z < N; z++) {
      for (let y = 0; y < N; y++) {
        for (let x = 0; x < N; x++) {
          const i = idx(x, y, z);
          if (!cur[i]) continue;
          let edge = false;
          for (const [dx, dy, dz] of [
            [1, 0, 0],
            [-1, 0, 0],
            [0, 1, 0],
            [0, -1, 0],
            [0, 0, 1],
            [0, 0, -1],
          ] as const) {
            const nx = x + dx;
            const ny = y + dy;
            const nz = z + dz;
            if (nx < 0 || ny < 0 || nz < 0 || nx >= N || ny >= N || nz >= N || !cur[idx(nx, ny, nz)]) {
              edge = true;
              break;
            }
          }
          if (edge) {
            shell[i] = s;
            next[i] = 0;
          }
        }
      }
    }
    cur = next;
  }
  for (let i = 0; i < cur.length; i++) {
    if (cur[i]) shell[i] = MAX_SHELL + 1;
  }

  return { scalar, shell, size: N };
}

export function countHighlighted(vol: Volume, peel: number, thresh: number) {
  const cut = Math.round(thresh * 255);
  let highlighted = 0;
  let remaining = 0;
  for (let i = 0; i < vol.scalar.length; i++) {
    if (vol.shell[i] === 0) continue;
    if (vol.shell[i] <= peel) continue;
    remaining++;
    if (vol.scalar[i] >= cut) highlighted++;
  }
  return { highlighted, remaining };
}

/** Highest score a demo grid is allowed to show. No site instrument is attached. */
export const MODEL_CONFIDENCE_CAP = 0.2;

export function modelConfidence(counts: { highlighted: number; remaining: number }) {
  if (counts.remaining === 0 || counts.highlighted === 0) return 0;
  const contrast = counts.highlighted / counts.remaining;
  const score = Math.min(MODEL_CONFIDENCE_CAP, contrast * MODEL_CONFIDENCE_CAP);
  return Math.round(score * 100) / 100;
}
