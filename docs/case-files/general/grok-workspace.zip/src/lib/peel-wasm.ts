export async function peelShellsWasm(scalar: Uint8Array, n: number): Promise<Uint8Array | null> {
  try {
    const res = await fetch("/peel.wasm");
    if (!res.ok) return null;
    const { instance } = await WebAssembly.instantiate(await res.arrayBuffer());
    const exp = instance.exports as {
      memory: WebAssembly.Memory;
      alloc: (len: number) => number;
      peel_shells: (scalarPtr: number, n: number, outPtr: number) => void;
    };
    const len = scalar.length;
    const scalarPtr = exp.alloc(len);
    const outPtr = exp.alloc(len);
    new Uint8Array(exp.memory.buffer, scalarPtr, len).set(scalar);
    exp.peel_shells(scalarPtr, n, outPtr);
    const out = new Uint8Array(len);
    out.set(new Uint8Array(exp.memory.buffer, outPtr, len));
    return out;
  } catch {
    return null;
  }
}
