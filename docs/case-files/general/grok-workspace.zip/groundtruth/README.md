# GroundTruth AR

Field layer for a lost-person and terrain-ranking workflow. Public maps go in. Ranked review polygons come out. A phone draws those polygons. It does not decide what is underground.

Lost-person behavior is the prior: Koester / ISRID, the 2008 set of 41 categories or the later set of 75. Historical roads, haul grades, drains, and canopy change are the features that prior attaches to.

## What a run emits

`site/data/zones.geojson`

Each feature is a polygon:

| Field | Meaning |
|---|---|
| `score` | Relative rank inside this AOI. Not a probability of a grave. |
| `drivers` | Which ring, wedge, historical feature, and elevation term fired. |
| `lpb_table` | `lpb41` or `lpb75` |
| `lpb_row` | Subject, ecoregion, terrain, season |
| `n` | Sample size on that row |
| `fallback` | `lpb41` when the 75-row is too thin |
| `align_error_m` | Georeferencing or GPS error. The client will not pretend to be finer than this. |

No body depth. No bone percentage. No coordinate written past the alignment error.

## Pipeline

```text
aoi/aoi.geojson
  -> fetch        USGS 3DEP 1 m DEM, clipped. Sentinel-2 scene list. Historical topo if you add it.
  -> terrain      Hillshade. Depression depth. Keep only sinks deeper than the local noise floor.
  -> canopy       Sentinel-2 NDVI change at 10 m. Labeled canopy change, not nitrate.
  -> rank         LPB rings, dispersion wedge, track-offset against features as of the loss date.
  -> filter       Drop building, mapped pipe, current road, one-pixel pits. Keep abandoned grades and mine features.
  -> publish      zones.geojson and zones.kml onto GitHub Pages.
```

GitHub Actions workflow: `.github/workflows/aoi.yml`, `workflow_dispatch` with `table` (`lpb41` | `lpb75`) and `subject`. One corridor per run. Do not push a statewide lidar job at a free runner.

Licensed ISRID distance tables stay out of a public repo. Mount them at run time.

## Phone

AR.js draws a zone’s label only when the phone is inside 50 m and the reported GPS accuracy is better than `align_error_m`. Otherwise the UI is a MapLibre map of the polygon.

Drawn: polygon, historical grade, contour, score, drivers. Not drawn: a marker under the ground, a dig point, a centroid promoted to a new target.

A tap queues a note (photo, time, GPS accuracy). Notes do not move a score until the next rank run.

## Layout

```text
groundtruth/
  aoi/aoi.geojson
  lpb/                      # private. not committed when the repo is public
  profiles/active.json
  pipelines/
    fetch.py
    terrain.py
    canopy.py
    rank.py
    filter_fp.py
    publish.py
  site/
  .github/workflows/aoi.yml
```

`profiles/active.json`:

```json
{
  "subject": "hiker",
  "eco": "temperate",
  "terrain": "mountain",
  "season": "any",
  "light": "any",
  "table": "lpb75",
  "min_n": 30,
  "date": "2018-02-17"
}
```

`date` is the loss date. Roads and drains are read as of that date, not as of today.

## Rank

```python
def rank(zones, profile, layers):
    features = layers.at(profile.date)
    kept = []
    for z in zones:
        z.score = (
            in_ring(z, profile.rings_mi)
            * in_wedge(z, profile.dispersion)
            * near_feature(z, features, profile.places, profile.offset_ft)
            * elev_ok(z, profile.elev_ft)
        )
        z.drivers = driver_list(z, profile, features)
        if z.score > 0 and profile.n >= profile.min_n:
            kept.append(z)
    return sorted(kept, key=lambda z: z.score, reverse=True)
```

Swap `lpb41.csv` for `lpb75.csv` and rerun. Publish which zones rose, which fell, and which layer moved them.

## Limits that are in the code on purpose

- A 1 m DEM does not resolve a 10–50 cm burial. Shallow sinks are mostly noise, tree-throw, and fill artifacts.
- Sentinel-2 is 10 m. Use it for canopy and corridor change only.
- PlanetScope and 8th Wall are paid. This repo does not depend on them.
- Phone GPS under canopy is meters, not centimeters.
- Missing GPR, soil chemistry, or DNA is “not in this run.” The ranker does not invent those signals.
- If a zone is only weakly supported and was not killed by the filter, it is marked `insufficient` and is not streamed.

## Sources

Use these URLs. A few links circulating with this project point at the wrong page or the wrong claim.

| Source | Use it for | URL |
|---|---|---|
| NIJ webinar, 18 Apr 2024 | GPR and UAV LiDAR on simulated graves (pig proxies), including limits | https://nij.ojp.gov/media/video/forensic-use-gpr-and-lidar-technology-clandestine-grave-detection |
| Berezowski et al. 2022, *Forensic Sci Int Synerg* | Geographic profiling, then LiDAR, then near-surface geophysics. PMID **35966608**, not 34212345. The paper does not establish a nitrate detector. | https://pubmed.ncbi.nlm.nih.gov/35966608/ |
| ScienceAlert, 3 Aug 2018 | Terrestrial lidar saw elevation change on researched burials. Not an airborne canopy product. | https://www.sciencealert.com/lidar-unmarked-graves-murder-victims-forensic-science |
| USGS 3DEP | 1 m DEMs and point clouds | https://www.usgs.gov/3d-elevation-program |
| FlySight OPENSIGHT | Airborne SAR AR console. A comparable for overlaying GIS in a mission display, not a ground grave scanner. | https://www.flysight.it/groundbreaking-use-for-search-and-rescue-systems/ |
| CrimeDoor (PR Newswire, 23 Nov 2020) | Living-room true-crime AR. Entertainment comparable only. | https://www.prnewswire.com/news-releases/recreate-the-murder-scenes-of-ted-bundy-the-menedez-brothers-black-dahlia-and-selena-in-your-living-room-using-the-new-augmented-reality-app-crimedoor-301178932.html |
| QGIS | Desktop GIS. Cloth-simulation canopy filters and sink tools come from PDAL, GRASS, SAGA, or Whitebox, not from QGIS core alone. | https://qgis.org/ |
| CloudCompare | Point-cloud diffs and density | https://www.cloudcompare.org/ |
| Koester, *Lost Person Behavior* (dbS, 2008) and later ISRID briefings | The 41-category tables and the later 75-category set. Load a licensed copy. Do not commit it. | https://www.dbs-sar.com/ |

NRCan high-resolution elevation and the GraveStory package id were not re-checked for this file. Add them when the link resolves.

## Status

Specification and job contract. `pipelines/*.py` are the next files to implement, starting with `rank.py` on a toy AOI and a two-row sample profile so the 41-versus-75 diff is visible before a real corridor is loaded.
