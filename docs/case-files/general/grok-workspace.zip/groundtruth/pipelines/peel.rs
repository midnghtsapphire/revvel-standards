// Shell peel for a measured scalar grid.
// The grid is whatever the instrument recorded (GPR amplitude, CT number).
// It is not grams per cubic centimeter inferred from a photo or a LiDAR cloud.
// LiDAR and a NeRF do not fill interior voxels.

use ndarray::Array3;

pub struct Peel {
    pub highlight_at: f32,
}

impl Peel {
    pub fn alpha(&self, scalar: &Array3<f32>, shells_to_drop: usize) -> Array3<f32> {
        let shell = shell_index(scalar);
        let (nx, ny, nz) = scalar.dim();
        let mut alpha = Array3::zeros((nx, ny, nz));
        for z in 0..nz {
            for y in 0..ny {
                for x in 0..nx {
                    let s = shell[[x, y, z]];
                    if s == 0 || s <= shells_to_drop as u16 {
                        alpha[[x, y, z]] = 0.0;
                    } else if scalar[[x, y, z]] >= self.highlight_at {
                        alpha[[x, y, z]] = 1.0;
                    } else {
                        alpha[[x, y, z]] = 0.10;
                    }
                }
            }
        }
        alpha
    }
}

fn shell_index(scalar: &Array3<f32>) -> Array3<u16> {
    let (nx, ny, nz) = scalar.dim();
    let mut occ = Array3::from_elem((nx, ny, nz), false);
    for ((x, y, z), v) in scalar.indexed_iter() {
        if *v > 0.0 {
            occ[[x, y, z]] = true;
        }
    }
    let mut shell = Array3::zeros((nx, ny, nz));
    for s in 1u16..=10 {
        let mut edge = Vec::new();
        for z in 0..nz {
            for y in 0..ny {
                for x in 0..nx {
                    if !occ[[x, y, z]] {
                        continue;
                    }
                    let mut boundary = false;
                    for (dx, dy, dz) in [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)] {
                        let nxv = x as isize + dx;
                        let nyv = y as isize + dy;
                        let nzv = z as isize + dz;
                        if nxv < 0
                            || nyv < 0
                            || nzv < 0
                            || nxv >= nx as isize
                            || nyv >= ny as isize
                            || nzv >= nz as isize
                            || !occ[[nxv as usize, nyv as usize, nzv as usize]]
                        {
                            boundary = true;
                            break;
                        }
                    }
                    if boundary {
                        edge.push((x, y, z));
                    }
                }
            }
        }
        for (x, y, z) in edge {
            occ[[x, y, z]] = false;
            shell[[x, y, z]] = s;
        }
    }
    for ((x, y, z), on) in occ.indexed_iter() {
        if *on {
            shell[[x, y, z]] = 11;
        }
    }
    shell
}
