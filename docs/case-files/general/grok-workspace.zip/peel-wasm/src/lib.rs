// Surface erosion. A voxel's shell is how many steps it sits in from the
// outside of the occupied scalar, not how far it is from the volume center.
// The scalar is an instrument value. Nothing in this crate names a material.

const MAX_SHELL: u8 = 10;

#[no_mangle]
pub extern "C" fn alloc(len: usize) -> *mut u8 {
    let mut buf = vec![0u8; len];
    let ptr = buf.as_mut_ptr();
    std::mem::forget(buf);
    ptr
}

#[no_mangle]
pub unsafe extern "C" fn dealloc(ptr: *mut u8, len: usize) {
    if ptr.is_null() || len == 0 {
        return;
    }
    drop(Vec::from_raw_parts(ptr, len, len));
}

/// `n` is the cube edge. `scalar` and `out` are each `n*n*n` bytes.
/// Occupied means scalar > 0. Shell 0 is empty. Shells 1..=10 peel from the
/// surface inward. Anything still occupied after that is shell 11.
#[no_mangle]
pub unsafe extern "C" fn peel_shells(scalar: *const u8, n: u32, out: *mut u8) {
    let n = n as usize;
    if n == 0 || scalar.is_null() || out.is_null() {
        return;
    }
    let len = n.saturating_mul(n).saturating_mul(n);
    if len == 0 {
        return;
    }
    let scalar = std::slice::from_raw_parts(scalar, len);
    let out = std::slice::from_raw_parts_mut(out, len);
    let shells = compute_shells(scalar, n);
    out.copy_from_slice(&shells);
}

fn compute_shells(scalar: &[u8], n: usize) -> Vec<u8> {
    let len = n * n * n;
    let mut occ = vec![0u8; len];
    for (i, v) in scalar.iter().enumerate() {
        if *v > 0 {
            occ[i] = 1;
        }
    }
    let mut shell = vec![0u8; len];
    for s in 1..=MAX_SHELL {
        let mut next = occ.clone();
        for z in 0..n {
            for y in 0..n {
                for x in 0..n {
                    let i = x + n * (y + n * z);
                    if occ[i] == 0 {
                        continue;
                    }
                    let mut edge = false;
                    for (dx, dy, dz) in [
                        (1isize, 0, 0),
                        (-1, 0, 0),
                        (0, 1, 0),
                        (0, -1, 0),
                        (0, 0, 1),
                        (0, 0, -1),
                    ] {
                        let nx = x as isize + dx;
                        let ny = y as isize + dy;
                        let nz = z as isize + dz;
                        if nx < 0
                            || ny < 0
                            || nz < 0
                            || nx >= n as isize
                            || ny >= n as isize
                            || nz >= n as isize
                            || occ[(nx as usize) + n * ((ny as usize) + n * (nz as usize))] == 0
                        {
                            edge = true;
                            break;
                        }
                    }
                    if edge {
                        shell[i] = s;
                        next[i] = 0;
                    }
                }
            }
        }
        occ = next;
    }
    for (i, on) in occ.iter().enumerate() {
        if *on == 1 {
            shell[i] = MAX_SHELL + 1;
        }
    }
    shell
}

#[cfg(test)]
mod tests {
    use super::compute_shells;

    #[test]
    fn peels_a_solid_block_from_the_faces() {
        let n = 5usize;
        let scalar = vec![10u8; n * n * n];
        let shell = compute_shells(&scalar, n);
        let i = |x, y, z| x + n * (y + n * z);
        assert_eq!(shell[i(0, 2, 2)], 1);
        assert_eq!(shell[i(1, 2, 2)], 2);
        assert_eq!(shell[i(2, 2, 2)], 3);
    }
}
