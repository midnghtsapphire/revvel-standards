# Forensic Finders — Records Retrieval

A starter repository for source-attributed, reproducible public-record acquisition. Initial target: **CASE001, Brian Shaffer**, researching public GIS records around **1546 N High St, Columbus, Ohio**, over a requested 2000–2010 period.

## Installation

Requires Python 3.10+; no external Python packages.

```bash
python -m unittest discover -s tests -v
python -m hfmr.retriever --output evidence --number 1546 --street HIGH --start 2000 --end 2010
python -m hfmr.retriever --verify evidence
```

## GitHub Actions

- `.github/workflows/ci.yml`: offline tests on pushes and pull requests.
- `.github/workflows/retrieve.yml`: public-record acquisition every Monday at 11:23 UTC and on manual dispatch. Artifacts retained for 30 days.

To start manually, open **Actions → Public records acquisition → Run workflow**. Download the `case001-evidence-*` artifact from the completed run. `manifest.json` records per-layer errors and file SHA-256 hashes.

## Important limitations

The public Columbus ArcGIS endpoint and its schema have **not been live-validated** in this starter release. The initial layer IDs (5, 22) are provisional and must be confirmed against current metadata before relying on results. Address matching is broad, not an authoritative historical parcel search. The year constraint is applied only if a recognizable numeric year field exists; otherwise the returned raw records must be reviewed manually for dates. Missing records, failed requests, and truncated results are not evidence of no construction. No assertions about an individual or a crime follow from this dataset alone.

This is a **starter**, not the complete forensic research platform, and does not include LIDAR, GPR, social-media acquisition, or direct private-data access.

## Upload to GitHub

GitHub's web upload of a ZIP does **not** unpack it. Extract this ZIP first, then upload the contents (including `.github/workflows`) to the root of `freedomangelcorps/forensic-finders-records` using **Add file → Upload files**. Some mobile file pickers hide dot-prefixed folders; desktop upload or GitHub Desktop is more reliable. If GitHub asks you to create an initial README, you can do so before uploading the remaining files.
