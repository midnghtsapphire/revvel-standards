import tempfile
import unittest
from pathlib import Path
from hfmr.retriever import collect, run, verify


class RetrievalTests(unittest.TestCase):
    def test_collect(self):
        def fake(url):
            if url.endswith("?f=json"):
                return {"fields": [{"name": n} for n in ["SITE_ADDRESS", "OBJECTID", "ISSUED_YEAR"]], "objectIdField": "OBJECTID"}, "metadatahash"
            return {"features": [{"attributes": {"OBJECTID": 1, "SITE_ADDRESS": "1546 N HIGH ST"}}]}, "pagehash"
        result = collect("building", 1546, "HIGH", 2000, 2010, getter=fake)
        self.assertEqual(len(result["records"]), 1)
        self.assertTrue(result["year_filter_applied"])

    def test_no_year_field(self):
        def fake(url):
            if url.endswith("?f=json"):
                return {"fields": [{"name": n} for n in ["ADDRESS", "OBJECTID"]]}, "meta"
            return {"features": []}, "page"
        result = collect("engineering", 1546, "HIGH", 2000, 2010, getter=fake)
        self.assertFalse(result["year_filter_applied"])

    def test_manifest_integrity(self):
        def fake(layer, *args):
            return {"records": [{"OBJECTID": 1}], "truncated": False}
        with tempfile.TemporaryDirectory() as tmp:
            report = run(tmp, collector=fake)
            self.assertTrue(report["complete"])
            self.assertEqual(verify(tmp), [])
            file = Path(tmp) / report["files"][0]["name"]
            file.write_text("changed")
            self.assertEqual(verify(tmp), [file.name])

    def test_failures_not_silent(self):
        def bad(*args):
            raise ConnectionError("offline")
        with tempfile.TemporaryDirectory() as tmp:
            report = run(tmp, collector=bad)
            self.assertFalse(report["complete"])
            self.assertEqual(len(report["errors"]), 2)


if __name__ == "__main__":
    unittest.main()
