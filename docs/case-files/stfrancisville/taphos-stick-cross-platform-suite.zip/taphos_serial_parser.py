### Taphos-Stick Cross-Platform Asset Bundle ###
Asset Name: taphos_serial_parser.py
Target: 9745 Morris Road, St. Francisville, LA
System: M-TMAT Platform Compatibility Layer.