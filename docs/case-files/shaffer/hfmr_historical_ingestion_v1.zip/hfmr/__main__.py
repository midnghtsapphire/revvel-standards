import argparse,json
from .pipeline import analyze,verify_run
from .historical import run as historical_run,inspect as historical_inspect,verify as historical_verify
p=argparse.ArgumentParser(prog='python -m hfmr')
s=p.add_subparsers(dest='cmd',required=True)
a=s.add_parser('analyze');a.add_argument('--case',required=True);a.add_argument('--input',required=True);a.add_argument('--output',required=True);a.add_argument('--before');a.add_argument('--threshold',type=float,default=3.5);a.add_argument('--cell-size-m',type=float);a.add_argument('--origin-x',type=float);a.add_argument('--origin-y',type=float);a.add_argument('--crs')
h=s.add_parser('historical');h.add_argument('--case',required=True);h.add_argument('--before',required=True);h.add_argument('--after',required=True);h.add_argument('--output',required=True);h.add_argument('--threshold',type=float,default=3.5);h.add_argument('--min-pixels',type=int,default=2);h.add_argument('--band',type=int,default=1);h.add_argument('--resampling',choices=['nearest','bilinear'],default='bilinear')
i=s.add_parser('inspect');i.add_argument('--input',required=True)
v=s.add_parser('verify');v.add_argument('--output',required=True)
args=p.parse_args()
if args.cmd=='analyze':
  origin=None if args.origin_x is None or args.origin_y is None else [args.origin_x,args.origin_y]
  r=analyze(args.case,args.input,args.output,before=args.before,threshold=args.threshold,cell_size_m=args.cell_size_m,origin_xy=origin,crs=args.crs)
  print(json.dumps({'candidates':r['result']['candidate_count'],'output':args.output}))
elif args.cmd=='historical':
  r=historical_run(args.case,args.before,args.after,args.output,args.threshold,args.min_pixels,args.band,args.resampling)
  print(json.dumps({'candidates':r['outputs']['candidate_count'],'overlap':r['processing']['valid_overlap_fraction'],'output':args.output}))
elif args.cmd=='inspect':print(json.dumps(historical_inspect(args.input),indent=2))
else:
  ok=historical_verify(args.output) if ( __import__('pathlib').Path(args.output)/'difference.tif').exists() else verify_run(args.output)
  print('VERIFIED' if ok else 'FAILED');raise SystemExit(0 if ok else 1)
