# DEVELOPER AND VISITING LLM / AGENT HANDOFF GUIDE
## Wave-Based Geospatial Intelligence & Immutable Case Management Framework

---

## 1. Executive Summary & Core Philosophy

This notebook workspace hosts an advanced **Multi-Waveband Earth Observation & Subsurface Taphonomy Search Engine**. It combines multi-frequency Synthetic Aperture Radar (SAR), Ground-Penetrating Radar (GPR) dielectric physics, Electrical Resistivity Tomography (ERT), Short-Wave Infrared (SWIR) spectroscopy, and 10-year empirical decomposition decay models to detect both surface and subsurface missing persons targets.

### Fundamental System Guiding Principles
1. **Never Overwrite Historical Data**: Every calculation, satellite pass evaluation, or sensor fusion run produces an **immutable snapshot**. Even if an algorithm or parameter is later revised or determined to be flawed, historical snapshots remain permanently archived for forensic auditing and longitudinal comparison.
2. **Never Delete Code**: All software updates, scripts, functions, and pipelines must be versioned (`v1`, `v2`, `v3`, etc.) and preserved. Historical routines remain executable to reproduce previous snapshots.
3. **Deterministic Snapshot & Delta Architecture**: System updates calculate **deltas** against prior baselines, tracking probability shifts, coordinate drifts, and code modifications over time.
4. **Universal Handoff Protocol**: Any human developer, visiting LLM, or autonomous agent can instantly resume operations by inspecting the SQLite database (`geospatial_osint_resources_v2.db` & `case_management_system.db`), running the master engine (`bootstrap_wave_search_engine_v2.py`), or launching the QGIS project template (`search_mission_template.qgz`).

---

## 2. Case Management & Unique Key Architecture

Every missing person case registered in the system receives a **unique, immutable Case Key** linked to external law enforcement and forensic registry IDs.

### Case Identifier Structure
* **Format**: `MP-YYYY-ST-XXXXXX` (e.g., `MP-2006-OH-86C4C7`)
  * `MP`: Missing Person Indicator
  * `YYYY`: Year of Disappearance
  * `ST`: Two-Letter State Code
  * `XXXXXX`: 6-Character SHA-256 Hash derived from `[Full Name] + [NamUs ID] + [Police Incident ID]`

### Cross-Referenced Identity Fields
* **Primary Key**: `case_key` (e.g., `MP-2006-OH-86C4C7`)
* **NamUs Identifier**: `namus_number` (e.g., `MP#5104`)
* **Law Enforcement Case #**: `police_case_number` (e.g., `CPD-06-024511`)
* **Demographics**: `full_name`, `dob`, `lkp_date`
* **Geospatial Anchor**: `lkp_location`, `lkp_coordinates` (WGS84 Lat/Lon)
* **Taphonomic Assumption**: `burial_type_assumption` (`Wrapped` / `Anoxic Enclosure` vs. `Unwrapped` / `Naked Matrix`)

---

## 3. Database Schema & Snapshot Engine

The system maintains two primary relational SQLite databases in `/workspace/scratch/` (and mirrored to `/workspace/out/`):

### A. `case_management_system.db` Schema

```sql
-- 1. Master Cases Registry
CREATE TABLE cases (
    case_key TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    namus_number TEXT UNIQUE,
    police_case_number TEXT UNIQUE,
    dob TEXT,
    lkp_date TEXT,
    lkp_location TEXT,
    lkp_coordinates TEXT,
    burial_type_assumption TEXT,
    case_status TEXT,
    created_at TEXT,
    updated_at TEXT
);

-- 2. Immutable Snapshots Table (Never Overwritten)
CREATE TABLE case_snapshots (
    snapshot_id TEXT PRIMARY KEY,       -- e.g., 'SNAP-32450D77'
    case_key TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    code_version TEXT NOT NULL,          -- e.g., 'v2.0.0'
    trigger_type TEXT NOT NULL,          -- 'INITIAL', 'MONTHLY_RECALC', 'CODE_UPDATE', 'SATELLITE_PASS'
    fused_probability REAL,              -- e.g., 0.9860 (98.6%)
    peak_coordinate_xyz TEXT,            -- JSON: {"x_m": 2.5, "y_m": -1.8, "z_m_depth": 1.2}
    sensor_fusion_params TEXT,          -- JSON list of active bands
    wave_physics_outputs TEXT,           -- JSON: dielectric er, R, velocity, ERT resistivity
    full_snapshot_state TEXT,            -- Complete serialized JSON state
    FOREIGN KEY(case_key) REFERENCES cases(case_key)
);

-- 3. Deltas Table (Tracks Changes Between Snapshots)
CREATE TABLE case_deltas (
    delta_id TEXT PRIMARY KEY,          -- e.g., 'DLT-0259AFD0'
    case_key TEXT NOT NULL,
    previous_snapshot_id TEXT,
    current_snapshot_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    probability_delta REAL,             -- e.g., +0.0610 (+6.10%)
    changed_fields TEXT,                -- JSON diff
    delta_summary TEXT
);

-- 4. Automated Notifications Table
CREATE TABLE notifications (
    notification_id TEXT PRIMARY KEY,
    case_key TEXT NOT NULL,
    snapshot_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    alert_level TEXT,                   -- 'CRITICAL', 'HIGH', 'INFO'
    notification_type TEXT,             -- 'TAK_COT_WEBHOOK', 'EMAIL_JSON'
    payload TEXT,                       -- JSON / CoT XML
    status TEXT
);

-- 5. Code Version Audit Log
CREATE TABLE code_history_audit (
    version_id TEXT PRIMARY KEY,
    script_name TEXT NOT NULL,
    version_tag TEXT NOT NULL,          -- e.g., 'v2.0.0'
    timestamp TEXT NOT NULL,
    git_hash_or_checksum TEXT,
    code_diff_summary TEXT,
    author_or_agent TEXT
);
```

### B. `geospatial_osint_resources_v2.db` Schema
Contains 19 Earth Observation satellite platforms, radar band parameters, and multi-sensor co-tasking synergy ratings (`satellite_constellations` table).

---

## 4. Multi-Waveband Physical & Sensor Fusion Suite

The search pipeline fuses **15 wave bands and sensing technologies** across orbital, aerial, and subsurface domains:

```
[ Orbital Spectrum ]
  ├── X-Band SAR (3.1 cm / 0.25m): Umbra-02, Capella Space (Micro-reflector & gear)
  ├── C-Band SAR (5.5 cm): Sentinel-1A/C, RADARSAT RCM (Bitemporal InSAR Coherence)
  ├── S-Band SAR (9.3 cm): NovaSAR-1 (Medium canopy penetration)
  ├── L-Band SAR (24 cm): NISAR, ALOS-2/4, SAOCOM (Deep canopy foliage penetration)
  ├── P-Band SAR (70 cm / 435 MHz): ESA BIOMASS (Ground-trunk interface & 3D TomoSAR)
  ├── Ka-Band Radar (0.8 cm / 35.7 GHz): SWOT Satellite (Water surface elevation)
  ├── VSWIR Hyperspectral (400-2500 nm): NASA EMIT, DLR EnMAP, ASI PRISMA (Clays & SWIR 1720nm lipids)
  ├── SIF Fluorescence (670-780 nm): ESA FLEX, TROPOMI (Pre-visual root leachate stress)
  └── GNSS-Reflectometry (19 cm L1): NASA CYGNSS (Sub-canopy soil moisture)

[ Subsurface & Field Physics ]
  ├── GPR Subsurface Waves (225-500 MHz): Dielectric boundary reflection R = 0.4854
  ├── ERT Resistivity (Dipole-Dipole): High-resistivity insulating shell (>180 Ω·m)
  ├── Thermal Infrared (3-12 µm): Drone FLIR active heat retention
  └── Gravimetry & Magnetics: GRACE-FO void mass displacement & quantum magnetics
```

### Dielectric Wave Formulas
1. **Fresnel Reflection Coefficient ($R$)**:
   $$R = \frac{\sqrt{\epsilon_{r1}} - \sqrt{\epsilon_{r2}}}{\sqrt{\epsilon_{r1}} + \sqrt{\epsilon_{r2}}}$$
   * *Moist Clay Matrix* ($\epsilon_{r1} = 25.0$) vs *Anoxic Adipocere Mass* ($\epsilon_{r2} = 3.0$) $\implies \mathbf{R = 0.4854}$.
   * *Unwrapped / Dispersed Matrix* ($\epsilon_{r2} = 23.5$) $\implies \mathbf{R = 0.0381}$.
2. **Two-Way Wave Velocity ($v$)**:
   $$v = \frac{c}{\sqrt{\epsilon_r}}$$
   * Wave velocity in moist clay = $0.060\text{ m/ns}$.
   * Wave velocity in adipocere mass = $0.1731\text{ m/ns}$.

---

## 5. Automated Recalculation & Notification Workflow

### Scheduled Recalculation Trigger
The system supports scheduled **monthly/annual re-runs** or **code modification triggers**:
1. Iterate through all active records in `cases`.
2. Execute `bootstrap_wave_search_engine_v2.py` with updated satellite pass data or modified wave formulas.
3. Call `case_snapshot_engine.create_snapshot()`.
4. The engine compares new probability $P_{\text{new}}$ with previous baseline $P_{\text{old}}$:
   * If $\Delta P = P_{\text{new}} - P_{\text{old}} \ge 0.02$ (+2%) or $P_{\text{new}} \ge 0.90$, a **CRITICAL** notification is dispatched.
   * Creates a `TAK_COT_WEBHOOK` event payload (`b-m-p-s-m` marker) for direct consumption by ATAK/WinTAK or email webhooks.

---

## 6. Key Executable Scripts & Artifact Map

All core deliverables reside in `/workspace/scratch/` and `/workspace/out/`:

| File Artifact Name | Type / Format | Purpose & Description |
| :--- | :--- | :--- |
| **`bootstrap_wave_search_engine_v2.py`** | Standalone Python CLI | Master search engine executing 15-band satellite query, GPR wave math, 3D voxel grid scan, and CoT XML export. |
| **`case_snapshot_engine.py`** | Python Database Engine | Manages unique case registration, immutable snapshot archiving, delta calculation, and notification dispatch. |
| **`case_management_system.db`** | Relational SQLite DB | Primary database containing `cases`, `case_snapshots`, `case_deltas`, `notifications`, and `code_history_audit`. |
| **`geospatial_osint_resources_v2.db`** | Relational SQLite DB | Master catalog of 19 satellite platforms, radar bands, revisit cycles, and synergy scores. |
| **`search_mission_template.qgz`** | QGIS Project Archive | Self-contained QGIS project bundling styled GeoTIFF rasters, GeoJSON targets, `.qml` styles, and PyQGIS hooks. |
| **`startup.py`** | PyQGIS Startup Hook | Automatic script placed in QGIS profile to load and style layers on project open. |
| **`auto_apply_qgis_styles.py`** | PyQGIS Script | Programmatically repaints active QGIS canvas with Thermal and Viridis `.qml` color ramps. |
| **`subsurface_3d_probability_map.png`** | PNG Visualization | 4-panel dashboard showing 3D isosurface, 2D depth slice ($Z=1.2\text{m}$), vertical cross-section, and dielectric profile. |
| **`synthetic_2d_radargram.png`** | PNG Visualization | Synthetic 2D GPR B-scan comparing side-by-side hyperbolic wave reflections for wrapped vs unwrapped targets at 1.2m. |
| **`wrapped_vs_unwrapped_decay_plot.png`** | PNG Visualization | 10-year longitudinal decay curves for GPR reflection $R$, ERT resistivity, and fused probability. |

---

## 7. Direct Instructions for Visiting LLMs / Agents

When taking over or extending this workspace:

1. **Check System Health & DB State**:
   ```bash
   python3 /workspace/scratch/case_snapshot_engine.py
   ```
2. **Execute Full Wave Search Pipeline**:
   ```bash
   python3 /workspace/scratch/bootstrap_wave_search_engine_v2.py --mode full
   ```
3. **Register New Code Updates**:
   Always call `log_code_version()` inside `case_snapshot_engine.py` whenever you modify search algorithms or add new wave formulas.
4. **Adding New Satellites or Bands**:
   Insert new entries into `geospatial_osint_resources_v2.db` under table `satellite_constellations`. Do **NOT** delete existing rows.
5. **Publishing Artifacts**:
   Develop and test scripts inside `/workspace/scratch/`. Copy completed, verified files to `/workspace/out/` **exactly once** to publish to Studio.

---
*Guide compiled and verified for immediate developer and agent handoff.*
