import sys
import os

# Standalone Cron Script for Automated Monthly Case Recalculation
SCRATCH_DIR = "/workspace/scratch"
sys.path.append(SCRATCH_DIR)

from bootstrap_wave_search_engine_v2 import run_automated_cron_recalculation

if __name__ == "__main__":
    print("[+] TRIGGERING AUTOMATED MONTHLY CASE RECALCULATION CRON ROUTINE...")
    run_automated_cron_recalculation(trigger_reason="AUTOMATED_MONTHLY_SCHEDULED_CRON")
