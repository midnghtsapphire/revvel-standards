# Sprint state

**As of 2026-11-14 UTC: local handoff; activation blocked; quiet mode.** This document records an internal script bundle, not a launched service.

## Current scope

The script, trusted Gitar request template, saved replies, environment example, control/publisher/review-relay/CI workflows, and offline tests are complete locally. **All 26 offline tests passed with no live API calls**. Workflow parsing/lint checks are complete, with the supported `queue: max` compatibility exception documented in TEST_RESULTS. This is local evidence, not a connected-account acceptance result. The documentation handoff contains README, blueprint, changelog, sprint state, kanban cards, conditional roadmap, internal-value brief, license, and TEST_RESULTS. No remote installation is certified.

The designed path is authorized GitHub comments → approved WR workflow or PR Gitar request → visible activity records → current-head signed Facebook draft → required human review → audreybuildsai Page publication. Slack is optional outbound notifications only.

## Blockers before any connected activation

1. **Exact repository.** Audrey must confirm `OWNER/REPO`. Saved `midnghtsapphhire/manus` returned 404. Do not silently use another spelling or the read-only governance repository `midnghtsapphire/revvel-standards`.
2. **Approved upstream work workflow.** Confirm the active `WORK_REQUEST_WORKFLOW` filename and inputs `work_request_number`/`requested_by`. Validate viability/approval enforcement and linked-PR creation/Gitar invocation; this bridge is not the upstream builder.
3. **Gitar setup.** Confirm installation, actual author identities, processing scope, trusted `gitar-task.txt`, and Allowed bots including the actual request author, ordinarily `github-actions[bot]`.
4. **Meta setup.** Official Facebook Login and `/me/accounts` must confirm audreybuildsai's numeric Page ID, Page tasks/token, permission/access requirements, and supported explicit Graph version. No token belongs in chat or Git.
5. **Publication gate.** Configure required reviewers on `facebook-publication` before enabling anything, verify GitHub plan/visibility support and trusted branches, and isolate the Page secret. The repository Page ID, signed Page ID, publisher Page ID, and approved Environment Page ID must match.
6. **Slack destination, if wanted.** Confirm channel and create an authorized incoming webhook independently of the attached Manus Slack connector. Leave optional notification configuration unset otherwise.
7. **Quiet-mode release and economics.** Audrey must authorize each activation. No cron before an `exit-quiet-mode` issue and explicit approval. Confirm who funds Audrey's labor, amount, and start date; absent that decision, expanded work remains Not Now.

## Acceptance still required

The reported offline checks do not exercise live providers. Once separately authorized, connected acceptance should show a collaborator command accepted and an unauthorized command rejected; an approved issue dispatch with a linked PR; Gitar activity mirrored without recursive requests; and a valid current-head draft whose exact text/hash/destination appear before protected approval.

Publication acceptance must prove a configured reviewer gate blocks an unapproved job, stale/altered/private sources are rejected, the approved Page destination is stable, and a single approved attempt records its receipt. Ambiguous-attempt recovery must be documented without blindly retrying a POST. Fork relay acceptance must verify authoritative re-fetch, reject forged/mismatched objects, and disclose deleted/unseen-edit coverage gaps. These are future acceptance criteria, not completed actions.

The publisher serializes per repository with `queue: max`, retaining up to 100 pending runs; over-capacity draft comments require inspected manual requeue. The main audit workflow has no concurrency group and deduplicates best effort during overlapping runs. Neither the queue nor audit is lossless/exactly once.

## Explicit exclusions

No deployment, account access, live GitHub/Slack/Facebook writes, enabled scheduling, public HTTP service, Slack/Facebook intake, arbitrary comment-code execution, app build, fundraising, or monetization program is authorized by this sprint state. Completion markers do not override upstream viability or launch approval.

## Next decision

Audrey confirms the repository and either approves a bounded connected-setup phase or leaves the bundle dormant. The owner should then update this state with actual evidence and date, not inferred success. See [KANBAN_CARDS.md](KANBAN_CARDS.md) for local cards and [README.md](README.md) for setup and recovery.
