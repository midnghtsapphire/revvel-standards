# Changelog

## Unreleased — local baseline, 2026-11-14 UTC

Implemented and documented the internal GitHub/Gitar-to-Facebook bridge, its saved-reply commands, repository-root installation shape, and Python standard-library CLI. The bridge supports approved PR requests, dispatch to an existing approved issue/work-request workflow, and GitHub-visible Gitar activity records on PRs and recognized linked same-repository issues.

Added bridge-specific current-head completion markers, `/audrey finish <commentid>` as a valid-source draft-queue retry only, and signed public-repository publication drafts. Draft integrity includes the exact message, source-body hash, current PR head, and numeric Facebook Page ID. Publication preparation produces an exact-payload SHA-256 for review; the publish job uses the protected `facebook-publication` Environment, which must have required reviewers configured by the operator.

Added the read-only/no-checkout fork review-event relay and trusted controller's authoritative re-fetch/identity validation. Deleted fork review comments and unseen intermediate edits remain coverage limits. No lossless or hidden-agent audit claim is made.

Added opt-in flags, external-write `--apply` gate, optional outbound Slack webhook notifications, pending-marker recovery, and no blind Facebook POST retries. Added blueprint, sprint/card state, proposed roadmap, internal-value brief, validation results, and All Rights Reserved license.

All 26 offline tests passed with no live API calls. All workflows were parsed/lint-checked with a documented compatibility exception: actionlint v1.7.12 does not yet recognize GitHub's supported `queue: max`; no other findings remain. Added fork-review provenance and timestamp-independent publication-ledger regressions. Signed drafts bind the numeric Page ID, and the draft dedup key permits a fresh correctly bound draft after a destination configuration change. API redirects are blocked before credentials can be forwarded; Facebook feed posts use form-encoded requests. Publisher serialization uses `queue: max` with up to 100 pending runs; over-capacity draft comments remain available for inspected manual requeue. Main audit runs retain events without a concurrency group; comment deduplication under overlap remains best effort.

### Not released or verified live

No confirmed target-repository installation, Gitar configuration, Meta authorization, numeric Page selection, Slack channel/webhook, required-reviewer setup, workflow run, or Page publication occurred. Governance repository data was read but not modified. Offline code-test outcomes are separate from connected-account acceptance.

The exact repository and upstream approved workflow remain blockers. Defaults remain quiet. No revenue, customer traction, fundraising, or scheduled delivery commitment is claimed.
