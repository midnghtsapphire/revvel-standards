# Local kanban cards

These are Markdown handoff cards, not tasks created in GitHub Projects, ClickUp, Slack, or another connected service. Audrey assigns execution owners and approves movement. Dates and effort are not committed.

## Documentation-ready

### DOC-01 — Internal bridge operations bundle

**Owner:** documentation handoff. **State:** written locally.

Deliver README, BLUEPRINT, CHANGELOG, SPRINT_STATE, KANBAN_CARDS, ROADMAP, INVESTORS_PACK, and LICENSE. Describe saved replies, exact configuration names, trust/approval boundaries, signed Page destination, fork-safe relay, quiet mode, and recovery. No account access or edits to code/workflows belong to this card. Implementation/test certification belongs to the implementation owner.

## Blocked — confirmation and authorization

### SETUP-01 — Confirm installation repository

**Owner:** Audrey. **State:** blocked.

Confirm the exact `OWNER/REPO` and trusted default branch. The saved `midnghtsapphhire/manus` returned 404. `midnghtsapphire/revvel-standards` is a read-only governance reference, not a fallback target. Done means a recorded explicit destination, not a guessed correction.

### SETUP-02 — Approve work-request execution path

**Owner:** Audrey/upstream workflow maintainer. **State:** blocked by SETUP-01.

Confirm active `WORK_REQUEST_WORKFLOW`, its two dispatch inputs, viability/approval enforcement, linked-PR creation, and PR-side Gitar invocation. Done means a reviewed trusted-default-branch workflow; no arbitrary comment shell/code and no build of HOLD/ARCHIVE work without Audrey's override.

### SETUP-03 — Configure Gitar and GitHub permissions

**Owner:** authorized repository/Gitar administrator. **State:** blocked by separate account-setup approval.

Confirm installation, configured `GITAR_LOGINS`, repository-owned task template, processing scope, and Allowed bots for the actual request author, ordinarily `github-actions[bot]`. Review token permissions, trusted checkout paths, fork relay validation, and serialized publication jobs. Done requires configuration evidence without disclosing credentials.

### SETUP-04 — Confirm Page and protected publication gate

**Owner:** Audrey/authorized Meta and GitHub administrator. **State:** blocked.

Use official Meta Login and `/me/accounts` to confirm audreybuildsai's numeric Page ID/tasks/token and supported Graph version. Bind `FACEBOOK_PAGE_ID` in controller/prepare and publisher configuration; set matching `APPROVED_FACEBOOK_PAGE_ID` in the approved Environment. Configure `facebook-publication` required reviewers before enabling publication. Done requires a verified available reviewer gate and secure secrets, not just an Environment name.

### SETUP-05 — Optional Slack notification channel

**Owner:** Audrey/authorized Slack administrator. **State:** optional; channel unknown.

Confirm the channel and obtain a separate incoming webhook. The attached Manus Slack connector is not runtime authorization for the script. Done means approved outbound-only delivery configuration; no Slack reads, intake, or credential exposure.

## Not Now — until explicit release

### VERIFY-01 — Bounded connected acceptance

**Owner:** to be assigned. **State:** blocked by setup cards and fresh authorization.

Exercise authorized/unauthorized controls, linked audit records, source/head/Page-bound signed drafts, protected exact-text/hash review, and one approved Page publication with receipt. Verify fork relay rejection of forged/mismatched data and document its deleted-comment limitation. Stop on ambiguous writes; inspect the destination rather than blindly retrying. No connected acceptance has been performed by this documentation task.

### RELEASE-01 — Exit quiet mode, only within approved scope

**Owner:** Audrey. **State:** Not Now.

Record funding of Audrey's labor and the approved activation scope. No cron until Audrey's `exit-quiet-mode` issue and explicit consent. Keep `ENABLE_AUDREY_BRIDGE`, `AUTO_START`, `QUEUE_FACEBOOK_PUBLICATION`, and `FACEBOOK_PUBLISH_ENABLED` false until their separate gates pass. Release is not automatic when a card moves or an issue opens.

### MEASURE-01 — Evaluate internal value

**Owner:** Audrey. **State:** proposed, not scheduled.

After an authorized pilot, compare measured operator time, audit usefulness, review burden, and actual cost. Decide retain, narrow, hold, or archive. No customer/revenue claim or productization is implied. See [INVESTORS_PACK.md](INVESTORS_PACK.md).
