# Audrey GitHub → Gitar → Facebook bridge

An internal Python script that turns GitHub saved-reply comments into approved work requests, records GitHub-visible Gitar activity on issues/work requests and pull requests, and prepares completed Gitar summaries for the Facebook Page **audreybuildsai**. Slack is optional, outbound notification only. This is not a web app, a public service, or a general-purpose comment-code executor.

**Status: local implementation and documentation; not installed or deployed. No account configuration or live writes are claimed.** The exact target repository remains unconfirmed. The saved `midnghtsapphhire/manus` lookup returned HTTP 404; do not silently correct the spelling or choose another repository. `midnghtsapphire/revvel-standards` was a read-only governance reference, not an authorized installation target.

Automation remains off by default. `ENABLE_AUDREY_BRIDGE=true` is a workflow activation gate; `AUTO_START=false`, `QUEUE_FACEBOOK_PUBLICATION=false`, and `FACEBOOK_PUBLISH_ENABLED=false` preserve deliberate operation. Under the supplied governance, no cron runs until Audrey opens an issue titled `exit-quiet-mode` and explicitly approves the relevant activation. That issue alone does not change configuration or authorize publication.

## What the commands do

Create GitHub saved replies containing these exact command bodies. Inserting a saved reply fills a comment; submitting the comment creates the event. It does not install a workflow or run arbitrary code by itself. [1]

```text
/audrey run
```

On an **open PR**, this posts the trusted repository-owned `gitar-task.txt` as a Gitar request. On an **issue/work request**, it dispatches the existing, active workflow named in `WORK_REQUEST_WORKFLOW`, on the repository's default branch, with inputs `work_request_number` and `requested_by`. That upstream workflow must enforce viability and approval before implementation, create/link a PR, and arrange PR-side Gitar invocation. An accepted dispatch is not proof that work started or completed. Gitar's documented interaction surface is PR comments; it is not an issue implementation engine. [2] [3]

```text
/audrey finish 123456789
```

Replace the number with the ID of the **Gitar conversation comment on this PR** containing the current-head completion markers. This retries draft queueing when a valid completion was missed. It does not declare unfinished work done, edit Gitar's comment, override stale markers, or publish to Facebook. Commands must occupy the entire comment body; only newly created commands from repository collaborators with write, maintain, or admin permission are accepted. Edits do not re-run commands.

`AUTO_START=true` optionally invokes the approved start path when an issue or PR is opened by a repository-write collaborator. Its default is false. Opening an issue/PR can still create an intake-controls comment once bridge workflows are enabled; `AUTO_START=false` disables starting work, not every bridge comment.

## 1. Confirm the repository and approval boundaries

Before installing anything, Audrey must confirm the exact `OWNER/REPO`, its default branch, and the approved work-request workflow filename. Do not install into the governance reference repository without separate authorization.

Classify this deliverable as `internal-script-automation`. A `/audrey run` is an execution request, not a substitute for the upstream viability decision. Work requests on HOLD or ARCHIVE stay there unless Audrey overrides them. Publication also needs launch qualification and an assigned approver; the bridge does not query or enforce Project v2 viability/marketing fields. The operator and upstream work workflow must enforce those governance decisions.

## 2. Install the files on the trusted default branch

Use Python **3.10 or newer**; the bridge uses only the standard library. No package installation, public HTTP endpoint, browser service, or local-PC polling is required. GitHub Actions is the intended runner, not something this documentation enables automatically.

The intended repository-root bundle is:

```text
audrey_bridge.py
gitar-task.txt
saved-replies.md
config.env.example
.github/workflows/audrey-bridge.yml
.github/workflows/audrey-facebook-publish.yml
.github/workflows/audit-review-events.yml
.github/workflows/ci.yml
tests/
README.md and the supporting governance/delivery documents
```

Keep `audrey_bridge.py` and `gitar-task.txt` side by side. Workflows assume installation at the confirmed repository root; adjust checkout/script paths if using a subdirectory. Review the actual delivered workflow files before activation. These filenames are the intended integration bundle, not evidence that any workflow has been installed or run remotely.

Use trusted default-branch code for privileged jobs. Never check out or execute untrusted PR-head code in a job with publishing credentials or write permissions. The review-event relay exists to reconcile events that cannot safely write directly; do not solve fork restrictions by exposing secrets to PR code. CI should validate the local script without live provider writes.

The complete suite passed **26 offline tests**, with no live API calls, on Python 3.12. All four workflows were parsed and lint-checked with one documented validator compatibility exception: `actionlint` v1.7.12 does not recognize GitHub's newly documented `queue: max`; no other findings remain. This is local test evidence, not connected-account acceptance. The unittest harness requires Python 3.11+; the script itself uses Python 3.10+. The delivered `ci.yml` runs offline tests on relevant pushes/PRs and manual dispatch; it does not start work or publish and is not gated by `ENABLE_AUDREY_BRIDGE`. See [TEST_RESULTS.md](TEST_RESULTS.md).

## 3. Configure Gitar separately

Install the [Gitar GitHub app](https://github.com/apps/gitar-bot) on the confirmed repository, confirm the actual Gitar author login, and review its processing scope and automatic-fix settings. In Gitar organization settings, an administrator must put **`github-actions[bot]` in Allowed bots** for workflow-authored requests to be accepted. If a separate GitHub App authors the request, allow that actual bot identity instead. An ordinary human's write permission does not make a bot-authored request eligible. [3]

The trusted `gitar-task.txt` must request the required completion convention. These are **bridge-specific markers**, not a claimed native Gitar completion webhook:

```text
<!-- AUDREY_DONE sha=<current 40-character PR head SHA> -->
<!-- AUDREY_SUMMARY_BEGIN -->
A reviewed, public-safe description of what was completed.
<!-- AUDREY_SUMMARY_END -->
```

The comment must be authored by a configured Gitar login. The SHA must match the current PR head. The summary must be nonempty and at most 6,000 characters after HTML removal/unescaping. A conservative credential-pattern check blocks some obvious leaks; it is not complete secret detection. Completion markers alone do not establish test success, merge status, deployment, or launch approval.

Gitar's own native automatic review/fix settings are separate. Turning bridge flags off does not necessarily stop an independently installed Gitar integration.

## 4. Set configuration without disclosing secrets

Use repository/Environment secrets for GitHub Actions, or a secure local environment for manual dry runs. Never place actual tokens, signing keys, or Slack webhook URLs in comments, Slack, chat, Git, or committed `.env` files. `config.env.example` is a template, not secret storage.

### GitHub and event settings

- `GITHUB_REPOSITORY`: confirmed `OWNER/REPO`; overridden by CLI `--repo`.
- `GITHUB_TOKEN`: Actions token or securely supplied token for local API reads/writes. `BRIDGE_GITHUB_TOKEN`, if set, takes precedence. Limit either token to the confirmed repository and necessary permissions.
- `BRIDGE_GITHUB_TOKEN`: optional separately authorized token when the Actions token cannot perform the required dispatch. Do not add one merely to bypass security restrictions.
- `GITHUB_EVENT_NAME` and `GITHUB_EVENT_PATH`: Actions-provided event name and JSON path; CLI `--event-name` and `--event-file` override them.
- `ENABLE_AUDREY_BRIDGE`: workflow-level opt-in, default off. The Python CLI does not read this variable; `--apply` remains its write gate.
- `AUTO_START`: optional issue/PR-opened work start; default `false`.
- `WORK_REQUEST_WORKFLOW`: the existing approved `.yml` or `.yaml` filename, not a path or comment-supplied name. Required for issue runs. Its `workflow_dispatch` must accept the two inputs documented above.
- `GITAR_LOGINS`: comma-separated allowlist, default `gitar-bot[bot],gitar-bot`. Match real GitHub attribution; do not add human accounts to make completion validation pass.

GitHub token permissions must cover the operations enabled: repository contents/metadata and PR/check reads, issue/PR comments, and Actions workflow dispatch when using issue intake. `repository_dispatch` additionally needs the endpoint's required write permission. Keep the publisher's Page secret unavailable to ordinary collector/CI jobs. GitHub documents token-created-event suppression and limited secrets/tokens on fork review events; inspect the actual workflow permissions rather than assuming every downstream event will fire. [4] [5] [6]

### Draft and Facebook settings

- `BRIDGE_SIGNING_KEY`: secret, at least **32 characters**. Used for draft HMAC signing and validation; available to collector, preparation, and publisher jobs as needed. Generate/store it securely outside Git/chat. Do not casually rotate it while drafts await review; existing signatures will become invalid.
- `QUEUE_FACEBOOK_PUBLICATION`: default `false`. When true and a new draft is written with `--apply`, optionally queues the publisher via `repository_dispatch`, event type `audrey-publication-ready`, carrying `draft_comment_id`. Queueing is not approval or publication.
- `FACEBOOK_PUBLISH_ENABLED`: default `false`. Explicitly enable only after all Page and required-reviewer checks below.
- `FACEBOOK_PAGE_ID`: confirmed numeric ID for audreybuildsai, not its username. Required before drafts can be generated; the exact numeric ID is signed into each draft and its approval hash, and must match during preparation and publication.
- `APPROVED_FACEBOOK_PAGE_ID`: must exactly equal `FACEBOOK_PAGE_ID` before a live post.
- `FACEBOOK_GRAPH_VERSION`: an explicitly chosen, currently supported version in `vNN.0` form. No guessed default. Verify support in Meta's documentation/dashboard before setting it.
- `FACEBOOK_PAGE_ACCESS_TOKEN`: the selected Page's access token, stored only in secure local storage or the protected publisher Environment secrets.

For the delivered workflows, set `ENABLE_AUDREY_BRIDGE`, `AUTO_START`, `WORK_REQUEST_WORKFLOW`, `GITAR_LOGINS`, `FACEBOOK_PAGE_ID`, `QUEUE_FACEBOOK_PUBLICATION`, and `FACEBOOK_PUBLISH_ENABLED` as **repository Variables**. In particular, the preparation job checks the repository publication flag before entering an Environment, and controller/prepare must be able to read the confirmed Page ID. Set `APPROVED_FACEBOOK_PAGE_ID` and `FACEBOOK_GRAPH_VERSION` as `facebook-publication` Environment Variables; any Environment override of `FACEBOOK_PAGE_ID` must remain identical to the signed/repository ID.

Use repository Secrets for `BRIDGE_SIGNING_KEY`, optional `BRIDGE_GITHUB_TOKEN`, and optional `SLACK_WEBHOOK_URL`; keep `FACEBOOK_PAGE_ACCESS_TOKEN` only in the protected Environment. If an Environment overrides the signing key, it must use the same key as draft generation/preparation. `GITHUB_TOKEN` is supplied by Actions with the workflow's explicit permissions. Do not export an attached Manus account token into this standalone script.

### Optional Slack setting

`SLACK_WEBHOOK_URL` is a separately authorized incoming webhook for the intended Slack channel. The channel is not yet confirmed. An attached Manus Slack connection does not supply this standalone script with a webhook and does not install Gitar's native Slack integration. Leave it unset until the channel and authorization are confirmed. The bridge sends short status notifications only; it neither reads Slack nor accepts Slack work requests. Webhooks are channel-bound secrets. Unconfirmed notification delivery is not retried automatically and must not replay work dispatch or Facebook posting. [7]

## 5. Identify and authorize audreybuildsai in Meta

Through Meta's official Facebook Login flow, authorize a Meta app with the required Page access. Use an authorized **User token** to read `/me/accounts?fields=id,name,access_token,tasks`, follow pagination, select the real audreybuildsai Page, and confirm its numeric ID and content-creation task. Store that Page's returned token as `FACEBOOK_PAGE_ACCESS_TOKEN`; do not use the discovery User token as a guessed Page token. This discovery/setup is outside the script. [8] [9]

Publishing requires `pages_manage_posts`, with its documented `pages_show_list` and `pages_read_engagement` dependencies and the appropriate Page task, such as `CREATE_CONTENT`. Confirm app access level, app roles, business verification/App Review requirements, and supported Graph version in the actual Meta app. Being a Page administrator is not automatically an app role. Tokens can be invalidated; do not describe them as permanent. [8] [9] [10]

The bridge makes no Facebook polling or webhook subscriptions. It publishes only the approved summary text through `POST /{page-id}/feed`; it does not ingest Facebook requests, manage visitor comments, or attach code/images. Facebook publication is immediate when that call succeeds. Drafts live on GitHub, not as scheduled Facebook posts. [11]

## 6. Configure human publication approval BEFORE enabling it

Create the GitHub Environment named exactly **`facebook-publication`**. Configure a required reviewer, restrict deployment to trusted branches, and review bypass/self-review settings appropriate to the owner. An environment name alone is **not** an approval gate. Required-reviewer availability depends on the GitHub plan and repository visibility; if the needed protection is unavailable, keep publication disabled until an equivalent explicitly approved gate is implemented. [12]

The intended `audrey-facebook-publish.yml` flow has a preparation job that exposes the exact draft and payload SHA-256, then a publish job referencing the protected environment. Store the Page access token in that environment. Review the exact `data.message`, destination Page ID, source Gitar comment, current PR head, and prepared hash before approving the pending job. Review public text for confidentiality, accuracy, scope, and launch readiness; a public repository can still contain sensitive material.

The script's `--approval-digest` validates exact payload identity. **It is not proof of human approval.** A local invocation with `--apply` bypasses the GitHub Environment interface; do not use it as a shortcut around review. Never enable automatic queueing/publishing before configuring and verifying the protected workflow.

For manual review/requeue, open GitHub **Actions → Audrey Facebook publication → Run workflow**, choose the trusted default branch, and enter `draft_comment_id`. The preparation summary exposes the exact payload before the protected job. The publisher serializes attempts per repository with `cancel-in-progress: false` and `queue: max`, retaining up to 100 pending runs. GitHub cancels additional runs when that queue is full; their draft comments remain on their PRs and can be manually requeued after inspection. This is a bounded queue, not a lossless work queue. [14]

## 7. Use the CLI safely

Examples below are documentation, not executed setup. Substitute real, authorized IDs locally. Omitting `--apply` suppresses external writes, but still performs authenticated GitHub reads. `prepare` also writes its local JSON output even without `--apply`.

```bash
cd /path/to/confirmed/repository
python3 --version
python3 audrey_bridge.py --help
python3 audrey_bridge.py event --help

# Requires a securely supplied GitHub token; performs GitHub reads.
python3 audrey_bridge.py --repo OWNER/REPO event \
  --event-name issue_comment --event-file /secure/path/event.json

# Reconcile current GitHub-visible PR activity; no external writes.
python3 audrey_bridge.py --repo OWNER/REPO sync --pr 42

# Validate a signed draft and its live source; write a local review artifact.
python3 audrey_bridge.py --repo OWNER/REPO prepare \
  --draft-id 123456789 --output /secure/path/publication.json

# Read approval_digest from the prepared JSON. Still no Facebook POST.
APPROVAL_DIGEST="$(python3 -c 'import json; print(json.load(open("/secure/path/publication.json"))["approval_digest"])')"
python3 audrey_bridge.py --repo OWNER/REPO publish \
  --draft-id 123456789 --approval-digest "$APPROVAL_DIGEST"
```

A publication dry run needs `BRIDGE_SIGNING_KEY`, a valid source draft, `FACEBOOK_PAGE_ID`, and `FACEBOOK_GRAPH_VERSION`, but no Page POST is sent. Substitute the real secure output path and IDs consistently.

The delivered controller also supports GitHub **Actions → Audrey Gitar bridge → Run workflow** with input `pr_number` to reconcile a PR. This Actions path runs `sync` with `--apply`, so it writes records/drafts and requires explicit bridge activation; it is not a dry run. The `relay --event-file <path>` CLI accepts the review-event envelope for authoritative re-fetching, but should normally be invoked only by the trusted relay controller.

Only after explicit activation, authorized bridge Actions jobs use the global `--apply` switch **before the subcommand**, for example:

```bash
python3 audrey_bridge.py --repo OWNER/REPO --apply event \
  --event-name "$GITHUB_EVENT_NAME" --event-file "$GITHUB_EVENT_PATH"
```

This example allows external writes and must not be used as an offline test. For Facebook, use the protected publication workflow rather than a direct live CLI command. If a source edit/new commit makes a draft stale, obtain a fresh current-head Gitar summary and prepare a new draft. Do not modify signed JSON or reuse the old approval digest.

## Audit coverage and recovery

The bridge snapshots Gitar conversation comments, edits/deletions when delivered, reviews, inline comments, commits attributed to configured Gitar GitHub identities, and checks attributed to the `gitar`/`gitar-bot` apps. PR activity is mirrored to same-repository issues linked in the PR body using recognized forms such as `Work request: #12` or `Closes #12`. Arbitrary `#12` mentions and cross-repository links are not used. PR bodies are the linking source, so the approved upstream workflow must add them.

Audit comments contain source IDs/URLs and timestamps. Repeated identical snapshots are deduplicated using marker hashes. Audit text neutralizes Gitar commands and mentions, rather than issuing them again. Gitar can update its dashboard comment in place; reconciliation sees current state, not every intermediate version. [3]

The read-only/no-checkout `audit-review-events.yml` uploads event JSON as untrusted data. A `workflow_run` controller on trusted default-branch code re-fetches the review/inline comment by ID and validates the PR and Gitar author before recording it. It never trusts artifact bodies or executes artifact content. Deleted fork review comments that cannot be independently re-fetched are not archived from the untrusted artifact.

This is **not a lossless record of every Gitar operation**. Hidden agent work is not exposed by these endpoints. Fork restrictions, GitHub Actions token-event suppression, missing check-to-PR associations, deleted history, and bot attribution gaps can prevent capture. Gitar organization audit logs are a separate Enterprise feature. Use an authorized manual `sync` for reconciliation; it cannot reconstruct unseen/deleted intermediate edits. The main audit workflow intentionally has no concurrency group to avoid dropping events; marker-based deduplication is best effort under overlapping runs, not exactly-once logging. [4] [5] [13]

Publication writes a GitHub **pending** marker before the Facebook POST, then records the returned Page/post ID and receipt. Treat this as a conservative at-most-once attempt strategy, not an exactly-once cross-provider transaction. The delivered publisher serializes runs per repository; the script's marker check alone is not a distributed lock, and direct concurrent CLI publishers are unsupported.

If the POST, receipt write, or job outcome is uncertain, **do not blindly retry**. A pending marker deliberately blocks further attempts for that payload. Inspect the real Page and source/draft/hash with the authorized operator, determine whether the post exists, and document the recovery decision in the PR/work request. Do not automatically delete markers. The script has no automatic unlock, rollback, or safe retry command; absence of a receipt is not evidence that no post was created. Similarly, an issue-dispatch pending marker means inspect Actions before repeating a work request.

To stop automation, set `ENABLE_AUDREY_BRIDGE=false`, `AUTO_START=false`, `QUEUE_FACEBOOK_PUBLICATION=false`, and `FACEBOOK_PUBLISH_ENABLED=false`; cancel queued/running jobs through the authorized owner and revoke/rotate affected secrets if needed. Turning variables off does not recall a post already sent or necessarily stop an already-running job.

## Supporting documents

[BLUEPRINT.md](BLUEPRINT.md) explains boundaries and trust flow. [SPRINT_STATE.md](SPRINT_STATE.md) and [KANBAN_CARDS.md](KANBAN_CARDS.md) track local handoff and activation blockers. [ROADMAP.md](ROADMAP.md) contains proposed milestones, not deadlines. [INVESTORS_PACK.md](INVESTORS_PACK.md) states the internal-tool value hypothesis without invented revenue. [CHANGELOG.md](CHANGELOG.md) records the local baseline. [LICENSE](LICENSE) reserves Audrey Evans / GlowStarLabs' rights; this is not an open-source license.

## References

Public documentation and supplied local research informed this guide. Local implementation/configuration is not evidence of a successful connected-account deployment.

[1]: https://docs.github.com/en/get-started/writing-on-github/working-with-saved-replies/creating-a-saved-reply "GitHub creating a saved reply"
[2]: https://docs.gitar.ai/introduction "Gitar introduction"
[3]: https://docs.gitar.ai/gitar-dashboard "Gitar dashboard and comment troubleshooting"
[4]: https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows "GitHub workflow events and fork restrictions"
[5]: https://docs.github.com/en/actions/how-tos/writing-workflows/choosing-when-your-workflow-runs/triggering-a-workflow "GitHub triggering workflows and token event suppression"
[6]: https://docs.github.com/en/rest/repos/repos#create-a-repository-dispatch-event "GitHub repository dispatch endpoint"
[7]: https://docs.slack.dev/messaging/sending-messages-using-incoming-webhooks "Slack incoming webhooks"
[8]: https://developers.facebook.com/documentation/pages-api/getting-started "Meta Pages API getting started"
[9]: https://developers.facebook.com/documentation/development/permissions "Meta permission reference"
[10]: https://developers.facebook.com/documentation/development/graph-api/overview/access-levels "Meta Graph API access levels"
[11]: https://developers.facebook.com/documentation/pages-api/posts "Meta Page posts and publishing"
[12]: https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments "GitHub deployment protection rules and environment secrets"
[13]: https://docs.gitar.ai/administration/audit-logs "Gitar organization audit logs"

[14]: https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-workflow-concurrency "GitHub concurrency and pending-run queue behavior"
