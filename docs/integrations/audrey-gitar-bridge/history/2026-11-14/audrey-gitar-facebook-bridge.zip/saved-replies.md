# GitHub saved replies

Create these in GitHub's saved-reply settings, then insert them into a new PR or issue conversation comment. Saved replies are reusable text, not executable GitHub features by themselves; the installed workflow reads the exact command. Only repository users with current write, maintain, or admin permission can start work.

## Run approved work

Save with title **Audrey — Run approved work** and body:

```text
/audrey run
```

On a PR this posts the trusted `gitar-task.txt` request to Gitar. On an issue/WR it dispatches the configured existing work-request workflow on the trusted default branch. That workflow must produce a PR with `Closes #123` or `Work request: #123` in its body. GitHub's number 123 is an example, not a configured target.

## Retry completion draft preparation

After Gitar's final conversation comment has the required current-head SHA and summary markers, save a reply titled **Audrey — Prepare final summary**:

```text
/audrey finish REPLACE_WITH_GITAR_COMMENT_ID
```

Replace the placeholder with the numeric Gitar comment ID before posting. The script does not accept a placeholder. This retries draft preparation only; it does not waive the completion markers, approve public publication, or publish to Facebook.

## Automatically run when opened

After installation and explicit enabling, set `AUTO_START=true` to start on new issue/PR creation by a user with repository write permission. The script calls the start handler directly; it does not depend on its own generated comment triggering another GitHub Actions run. Keep `AUTO_START=false` if you prefer to start each request with the saved reply. Both modes require `ENABLE_AUDREY_BRIDGE=true` in the repository variables; the package ships in quiet mode.

There is intentionally no arbitrary `/run <shell code>` command. Put approved code in your existing trusted workflow, not in comment text.
