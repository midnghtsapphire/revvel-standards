# Validation results

Validated on 2026-11-14 UTC in the Manus sandbox with Python 3.12.

`PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s tests -v` passed all **26 tests**. The tests use fake GitHub data and mocked network calls; they cover authorized commands, approved issue workflow routing, current-head completion markers, Gitar provenance, signed drafts, numeric Page ID approval binding, private-repository and stale-draft rejection, replay/uncertain-publication protection, dry runs, and fork-review relay provenance.

All four `.github/workflows/*.yml` files parsed successfully. Official `actionlint` **v1.7.12** validates the three other workflows without findings. For the publisher it does not yet recognize GitHub's currently documented `concurrency.queue: max`. That precise compatibility finding is filtered; no other workflow syntax/expression findings remain. The queue property is independently checked against GitHub's official documentation and parsed YAML: https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-workflow-concurrency . It is set to `max` with `cancel-in-progress: false`, as required. Workflow acceptance on the actual target repository is still an installation test, not a completed remote action.

GitHub Actions are pinned to verified full release commit SHAs. Local checks do not prove that Actions settings, GitHub plan-specific environment protections, Gitar installation, Meta permissions, or Slack authorization are configured.

`python3 audrey_bridge.py --help` completed successfully. The script uses only Python's standard library at runtime. The unittest harness uses Python 3.11+ convenience methods and was run on Python 3.12.

No live issue/PR comments, workflow dispatches, Git commits/pushes, Facebook posts, or Slack messages were sent. Governance was read from `midnghtsapphire/revvel-standards`; it was not modified. The exact saved tracking repository `midnghtsapphhire/manus` returned HTTP 404. Target repository confirmation and service authorization remain installation prerequisites.

The bridge records observable GitHub activity, not Gitar's hidden internal operations. Reconciliation and relay paths read authoritative current state; they cannot reconstruct every intermediate edit or deleted object. Deduplication of concurrent GitHub comments is best effort. Facebook publication is serialized by the workflow and guarded by a persistent pending marker; an uncertain write requires inspection rather than an automatic retry.
