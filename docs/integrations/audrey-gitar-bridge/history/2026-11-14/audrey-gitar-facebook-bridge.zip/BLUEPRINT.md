# Bridge blueprint

## Deliverable and authority

This is an `internal-script-automation` bundle for a confirmed GitHub repository, not an app, SaaS offer, or autonomous idea-to-product system. Audrey Evans is the final authority. The local baseline does not authorize deployment, account access, a scheduled job, or a Facebook post.

The target `OWNER/REPO` is pending. The saved `midnghtsapphhire/manus` lookup returned 404. The separately accessible `midnghtsapphire/revvel-standards` supplied governance only and is not an installation target. Do not infer an alternative repository.

GitHub holds commands, source records, work requests, PRs, signed draft comments, and publication receipts. Gitar performs approved PR work through its separately installed GitHub integration. Facebook receives only explicitly approved completed-summary text for audreybuildsai. Slack receives optional notifications through a separately authorized webhook; it supplies neither intake nor approval.

## Data and control flow

```text
Issue/PR opened
  → bridge enabled? create intake controls
  → AUTO_START false: wait for an authorized /audrey run comment
  → AUTO_START true: repository-write creator can request the start path

Issue /audrey run
  → validate collaborator and approved workflow filename
  → record dispatch pending
  → dispatch existing workflow on trusted default branch
  → upstream viability/approval → create/link PR → PR-side Gitar invocation

Open PR /audrey run
  → validate collaborator
  → post trusted gitar-task.txt; never execute comment-supplied shell/code
  → Gitar processes according to its installation and organization settings

GitHub-visible Gitar activity
  → collect authoritative sources or delivered conversation events
  → deduplicated inert audit comments on PR and linked same-repo WR/issues

Current-head Gitar completion comment
  → validate custom markers and summary
  → public repository only
  → sign exact draft, including numeric destination Page ID
  → GitHub draft comment; optional publisher queue, never approval

Publication preparation
  → verify HMAC, Page ID, live source-body hash, summary, PR head
  → expose exact data.message and canonical payload SHA-256
  → required reviewer approves protected facebook-publication job
  → revalidate → pending marker → Facebook POST → receipt/audit record
```

A completion comment is not a merge/deployment signal. The script does not read Project v2 viability, launch status, marketing readiness, or approver fields. Upstream work routing must enforce BUILD/approval before implementation; the human publication gate must enforce launch qualification before public dissemination.

## Runtime interfaces

`audrey_bridge.py` uses Python 3.10+ and the standard library. Its primary CLI operations are `event`, `sync`, `prepare`, and `publish`; `relay` accepts review-event artifact data for authoritative revalidation. Global `--repo` selects the confirmed repository and global `--apply` permits external writes. `ENABLE_AUDREY_BRIDGE` is a workflow gate, not a Python permission check. Dry runs still read GitHub; preparation writes a local JSON artifact.

The intended root-level workflows are `audrey-bridge.yml` for control/audit, `audit-review-events.yml` for the read-only review relay, `audrey-facebook-publish.yml` for preparation/protected publication, and `ci.yml` for local checks. Inspect their actual delivered contents and token permissions before enabling them. Nothing here claims remote installation or workflow success.

The delivered controller's manual dispatch accepts `pr_number`; the publisher's manual dispatch accepts `draft_comment_id`. Those Actions paths perform enabled live recording/publication operations, not CLI dry runs. The offline CI workflow runs on relevant push/PR events and manual dispatch without the bridge activation flag; it performs no live provider writes. All 26 offline tests passed. Workflows were parsed/lint-checked with the supported `queue: max` validator compatibility exception documented in TEST_RESULTS; this is not a connected-account pilot.

A PR run posts repository-owned `gitar-task.txt`. An issue run accepts only `WORK_REQUEST_WORKFLOW`, an active `.yml`/`.yaml` filename under `.github/workflows/`, and dispatches the repository default branch with `work_request_number` and `requested_by`. No workflow name/ref comes from comment text. The bridge does not build the project or manufacture an approved WR workflow.

## Fork-safe review relay

Review/inline-comment event jobs may have read-only tokens and unavailable secrets on forks. The relay workflow performs no repository checkout, uploads event JSON as data, and does not receive write or Page credentials. A trusted-default-branch controller job triggered by `workflow_run` downloads the artifact and invokes `relay`.

Artifact authors, bodies, URLs, and claimed bot identity are untrusted. The bridge accepts only review/inline-comment event types, checks the configured repository and positive PR/object IDs, re-fetches the review or comment from fixed GitHub API paths, verifies PR membership and configured Gitar author identity, and records the authoritative snapshot. It does not execute artifact content.

Deleted fork inline comments that cannot be independently re-fetched are not archived from the untrusted artifact. Intermediate edits may be lost before re-fetching. This safety choice deliberately limits coverage; the relay is not a lossless event archive.

## Draft integrity and destination binding

The Gitar conversation comment must include `AUDREY_DONE sha=<current40hex>` and `AUDREY_SUMMARY_BEGIN`/`AUDREY_SUMMARY_END` HTML-comment markers. `/audrey finish <commentid>` only retries queueing for a valid Gitar source on the same PR/current head. It never supplies a semantic completion override.

The signed draft data binds repository, PR number, current head SHA, Page name, numeric `page_id`, source comment ID, full source-body SHA-256, exact message, version, and timestamp. HMAC-SHA256 uses `BRIDGE_SIGNING_KEY` of at least 32 characters. The approval digest is SHA-256 of canonical draft data. Changing text, source, destination, or head invalidates the prepared approval path.

`FACEBOOK_PAGE_ID` must be configured before draft generation and accessible to controller and preparation jobs, as a confirmed repository variable. The publisher must use the same ID, and protected `APPROVED_FACEBOOK_PAGE_ID` must equal it. Meta's official `/me/accounts` discovery establishes the ID/token association outside the script. The script validates the Page ID with the Page token before posting; it does not prove that a display name equals a username.

Only public repositories can generate/publish Facebook drafts. Public visibility is not sufficient privacy review. Pattern screening cannot detect every secret, proprietary detail, or misleading claim. The required reviewer must inspect exact text and public-disclosure readiness.

## Write and approval boundaries

All external script writes require `--apply`. Facebook additionally requires `FACEBOOK_PUBLISH_ENABLED=true`, matching configured/approved/signed Page IDs, a supported explicit `FACEBOOK_GRAPH_VERSION`, and `FACEBOOK_PAGE_ACCESS_TOKEN`. Automatic queueing uses `QUEUE_FACEBOOK_PUBLICATION=true`; it merely requests the publisher workflow.

The publisher's preparation job displays the exact draft/hash before the publish job enters the protected `facebook-publication` Environment. Configure required reviewers before enabling publishing, verify plan availability, restrict trusted branches, and keep the Page token in Environment secrets. An unprotected environment or knowledge of the digest is not human approval. Direct local live CLI use must not bypass this policy.

Gitar installation, its bot allowlist for `github-actions[bot]`, and its own automatic-processing settings are separate from bridge flags. Bridge quiet mode does not necessarily stop Gitar's independent native automation.

## Audit coverage and failure model

Audit covers delivered/current GitHub-visible Gitar conversation comments, reviews, inline comments, attributed commits, and checks. Recognized PR-body links such as `Closes #12` and `Work request: #12` route mirrors to same-repository issues. Snapshot hashes deduplicate identical records; source URLs/IDs and timestamps support inspection. Audit text neutralizes command prefixes and mentions.

There is no hidden-agent trace capture, guaranteed intermediate-edit history, or exactly-once transaction across GitHub and Meta. Actions token-event suppression, fork/secrets restrictions, missing bot attribution, inaccessible/deleted content, and incomplete check associations limit coverage. Manual authorized `sync` reconciles current state only.

The main audit workflow has no concurrency group to avoid dropping audit events; marker-based deduplication is best effort when runs overlap. It is not exactly-once logging.

Pending markers precede work dispatch and Page posting. The publisher serializes per repository with `cancel-in-progress: false` and `queue: max`; comment markers alone are not a distributed lock. GitHub retains up to 100 pending runs and cancels additional runs if the queue is full. The signed PR draft remains available for inspected manual requeue via `workflow_dispatch`/`draft_comment_id`. The publication ledger key excludes draft timestamps so duplicate drafts of the same source summary share a pending/receipt guard. This is not a lossless queue, and direct concurrent CLI publication is unsupported.

An uncertain Page POST or later receipt failure leaves the payload blocked. Recovery requires inspecting the actual Page and source, documenting an operator decision, and avoiding blind POST retries or automatic marker deletion. No retry-unlock or automatic rollback is implemented.

Slack notification failures do not replay other writes. Tokens and webhook URLs never belong in GitHub comments, Slack, Git, or chat. No public HTTP receiver, Facebook ingestion, or local computer poller is needed.

## Release boundary

Keep `ENABLE_AUDREY_BRIDGE`, `AUTO_START`, `QUEUE_FACEBOOK_PUBLICATION`, and `FACEBOOK_PUBLISH_ENABLED` false until their individual gates are satisfied. No cron is activated without Audrey's `exit-quiet-mode` issue and explicit scope approval. Work in small reviewable PRs. Preserve filed legal records; this bundle changes none.

[README.md](README.md) is the setup/operations guide and contains official references. [SPRINT_STATE.md](SPRINT_STATE.md) records blockers; [ROADMAP.md](ROADMAP.md) contains proposed, conditional next steps.
