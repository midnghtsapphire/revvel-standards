# Proposed roadmap

This roadmap is conditional planning for an internal script. It is not a deployment promise, funded schedule, app roadmap, or monetization program. No milestone authorizes live writes; Audrey approves each gate. The current state is local handoff, unconfirmed repository, and quiet mode.

## Milestone 1 — Confirm a viable installation boundary

Confirm the exact repository, upstream approved WR workflow, trusted branch, and narrow deliverable scope. Apply the supplied governance rather than building every request. Record who funds Audrey Evans' labor, how much, and starting when. These economic facts are currently unknown; expanded work stays Not Now until Audrey supplies or explicitly overrides that gate.

**Proposed completion evidence:** confirmed destination and written bounded setup approval. Do not use the read-only governance repository as a guessed installation target.

## Milestone 2 — Review the dormant integration bundle

Review the script, trusted Gitar template, saved replies, example configuration, root-level workflows, and implementer's offline tests. Check `--apply` gating, default-off flags, exact issue-dispatch inputs, fork-safe relay source validation, same-repository linking, signed numeric Page destination, and pending-marker behavior. No connected acceptance or scheduling is part of this milestone by default.

**Proposed completion evidence:** reviewed files and actual offline results, with coverage limitations recorded. Small reviewable PRs are preferred after repository/commit authorization.

## Milestone 3 — Authorize and configure a bounded pilot

Separately approve Gitar installation/settings, minimal GitHub permissions, Meta Login/Page discovery, secure tokens, and a verified protected `facebook-publication` reviewer gate. Optional Slack notifications require a confirmed channel and their own incoming webhook. Disable native/bridge automation that is outside the pilot scope.

**Proposed completion evidence:** confirmed numeric Page ID, supported explicit Graph version, matching signed/configured/approved destination, and required-reviewer configuration. If the needed GitHub protection is unavailable, publication remains disabled.

## Milestone 4 — Verify one reviewed end-to-end path

Only after new authorization, demonstrate approved work routing and visible records, then a valid Gitar current-head completion draft. Review the exact message/hash/destination, approve through the protected environment, and record one Page receipt. Test stale/private/altered-source rejection and audit-relay validation without treating an ambiguous POST as safely retryable.

**Proposed completion evidence:** attributable PR/WR evidence and an inspected Page result, not inferred success from a workflow dispatch. No lossless hidden-agent audit is promised.

## Milestone 5 — Decide whether the internal tool pays for itself

Use measured time savings, review burden, hosting/Actions and integration costs, and audit usefulness to decide whether to retain the tool. A possible paid-client workflow benefit or explicitly budgeted internal sponsorship is a hypothesis, not revenue. No customer count, price, recurring revenue, funding, or launch date is established.

**Proposed completion evidence:** an owner-approved retain/narrow/hold/archive decision and a real labor-payment arrangement. Productization or external sales require a separate scoped viability request; they are not part of this bridge.

## Quiet-mode rules

Keep automation off until Audrey approves the exact activation. No cron before an issue titled `exit-quiet-mode` and explicit consent; that issue does not flip flags by itself. Auto-start, publisher queueing, and Page posting have separate switches and prerequisites. Do not add Facebook/Slack intake, a browser service, a local-PC poller, or a public app without a new request.

See [SPRINT_STATE.md](SPRINT_STATE.md) for current blockers and [README.md](README.md) for operational gates.
