# Facebook Page integration: audreybuildsai

The clarified target is the Facebook **Page** `audreybuildsai`, not the owner's personal profile. The official Pages API supports reading Page posts, receiving feed-change webhooks, and publishing as the Page. A minimal integration can therefore attach the Page to a GitHub/Gitar.ai/Slack workflow, but Facebook publishing should remain disabled until the owner explicitly approves what may become public. [1]

## Minimum authorization and Page identification

Create a Meta app with the Pages API use case and authorize it through Meta's supported Facebook Login flow. For Page discovery and reading Page-authored content, request `pages_show_list` and `pages_read_engagement`. Add `pages_manage_posts` only if publishing is explicitly wanted; its documented dependencies are `pages_show_list` and `pages_read_engagement`. The authorizing person must have the relevant Page task, including `CREATE_CONTENT` for publishing. These are Page permissions, not `user_posts`. [1] [2] [3]

With the authorized **User access token**, call `GET /me/accounts?fields=id,name,access_token,tasks` against a supported, explicitly configured Graph API version. Follow pagination, select the actual `audreybuildsai` Page, and confirm its numeric `id` and required tasks. Store that Page's returned `access_token` separately from the User token. `/me/accounts` is the current-user form of `/{user-id}/accounts`; Meta's getting-started guide demonstrates both forms. Do not use the Page username as an assumed numeric Page ID. If the Page is absent, resolve the user's Page access and consent rather than selecting a different Page. [3] [4]

For a longer-lived setup, exchange a valid short-lived User token server-side through `GET /oauth/access_token` with `grant_type=fb_exchange_token`, then request `/me/accounts` using the resulting long-lived User token. Meta says long-lived User tokens generally last about 60 days; Page tokens derived from them have no scheduled expiration, but can still be invalidated. Treat tokens and the app secret as secrets, keep them out of GitHub and Slack, and support reauthorization rather than promising a permanent token. [5]

## Supported Page API operations

**Read:** Use the Page token for `GET /{page-id}/feed?fields=id,message,created_time,permalink_url`. Meta documents `/feed` for listing Page posts and the Post reference documents `permalink_url`. Follow response pagination. Reading visitor/user-generated content on the Page can additionally require `pages_read_user_content`; do not promise that the two read/discovery permissions expose every visitor post or comment. [1] [2] [6] [7]

**Receive changes:** Add `pages_manage_metadata` and configure the app's Webhooks product with the **Page** object and `feed` field. Subscribe the individual Page using its Page token through `POST /{page-id}/subscribed_apps` with `subscribed_fields=feed`. Both the app-level and Page-level subscriptions must include the field. The official feed-webhook guide requires `pages_manage_metadata` and `pages_show_list`. This requires a reachable callback endpoint; a script without an HTTP receiver can read by polling instead, but cannot receive webhook deliveries. [8] [9]

**Publish, only after approval:** Use the Page token with `POST /{page-id}/feed`, supplying `message` and optionally `link`. This creates a post as the Page and returns its post ID. Meta's publishing guide states that immediate publication is the default. Do not mistake `published=false` with a future schedule for a human-approval gate: scheduled content can subsequently publish automatically. Keeping a draft outside Facebook and making no publishing call until approval is safer. Meta also limits post editing to posts created through that app. [6]

## Access review and safety caveats

For an owner-only app, Standard Access can suffice when the authorizing person also has a role on the Meta app. Meta's access-level documentation explicitly scopes this rule to apps created using an App Type; verify the actual dashboard/use-case requirements rather than promising a universal no-review exemption. Access for non-app-role users requires Advanced Access to the relevant permissions, with business verification and App Review requirements. Being a Page administrator is not the same as holding a role on the Meta app. [10]

Private GitHub issue titles, work requests, PR descriptions, code, Gitar.ai comments, and Slack messages can disclose sensitive information even when links themselves require login. Default to **no automatic Facebook publication**, reject private-repository-derived material by default, and require explicit review of the exact public text and links. This is a recommended privacy guardrail, not a claimed Meta API permission rule. Page authorization alone does not authorize public redistribution of private project activity. No browser or account was accessed, no credentials were requested, and nothing was built or deployed.

## One clarification question

“Should audreybuildsai be a source of posts or requests for GitHub and Slack, a destination for approved GitHub/Gitar.ai updates, or both?”

## References

[1]: https://developers.facebook.com/documentation/pages-api "Meta Facebook Pages API"
[2]: https://developers.facebook.com/documentation/development/permissions "Meta permissions reference"
[3]: https://developers.facebook.com/documentation/pages-api/manage-pages "Meta Manage a Page"
[4]: https://developers.facebook.com/documentation/pages-api/getting-started "Meta Get started with the Pages API"
[5]: https://developers.facebook.com/documentation/facebook-login/guides/access-tokens/get-long-lived "Meta long-lived access tokens"
[6]: https://developers.facebook.com/documentation/pages-api/posts "Meta Page posts"
[7]: https://developers.facebook.com/docs/graph-api/reference/post/ "Meta Graph API Post reference"
[8]: https://developers.facebook.com/docs/graph-api/webhooks/getting-started/webhooks-for-pages/ "Meta Webhooks for Pages"
[9]: https://developers.facebook.com/docs/graph-api/reference/page/subscribed_apps/ "Meta Page subscribed_apps reference"
[10]: https://developers.facebook.com/documentation/development/graph-api/overview/access-levels "Meta Graph API access levels"
