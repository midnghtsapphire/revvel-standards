# Integration source notes

Verified during this task on 2026-11-14 UTC. User identifies their Facebook Page as audreybuildsai. GitHub issue/work request and pull request activity are the intended Gitar record destinations. Facebook direction and exact GitHub/Slack destinations remain pending.

Gitar's public GitHub app is gitar-bot. Its GitHub-visible work includes PR comments, review findings, fixes committed to the branch, and dashboard edits. The dashboard is updated in place, so a snapshot-only poll cannot capture every intermediate edit. Sources: https://github.com/apps/gitar-bot ; https://docs.gitar.ai/introduction ; https://docs.gitar.ai/gitar-dashboard .

Gitar documents a native Slack app with notification and context retrieval functions. An attached Manus Slack connection does not automatically authorize a standalone script, nor does it imply Gitar's Slack app is installed. Source: https://docs.gitar.ai/integrations/slack .

Gitar organization audit logs are Enterprise-only. GitHub-visible events must not be represented as every internal agent operation. Source: https://docs.gitar.ai/administration/audit-logs .

GitHub PR conversation comments use the issues API. Reviews and inline comments have separate endpoints. Source: https://docs.github.com/en/rest/pulls/pulls .

GitHub workflow review/comment events may have restricted secrets and read-only tokens for forks. A default-branch scheduled REST collector avoids executing PR code but samples state, not a lossless webhook archive. Source: https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows .

Slack incoming webhook URLs are secrets tied to an authorized channel. Do not commit them. Source: https://docs.slack.dev/messaging/sending-messages-using-incoming-webhooks .

Governance repository midnghtsapphire/revvel-standards is accessible with default branch main. The exact saved tracking repository midnghtsapphhire/manus returned HTTP 404. Do not silently choose another target or publish a script there until clarified.
