# Hula Arcade contrast table

WCAG 2.x contrast ratios for every text/background pair used by the themes. AA needs 4.5:1 for normal text.

| Text | On | Ratio | Result |
|---|---|---|---|
| mint `#8EE59A` | ink `#14163A` | 11.47:1 | pass |
| blue_dk `#8FB4FF` | ink `#14163A` | 8.41:1 | pass |
| cream `#FFF4E0` | ink `#14163A` | 15.98:1 | pass |
| cream `#FFF4E0` | navy `#1B1F4B` | 14.33:1 | pass |
| night_muted `#A9A8D6` | ink `#14163A` | 7.68:1 | pass |
| night_muted `#A9A8D6` | navy `#1B1F4B` | 6.89:1 | pass |
| yellow `#FFD23F` | ink `#14163A` | 12.06:1 | pass |
| teal `#19C3B1` | ink `#14163A` | 7.87:1 | pass |
| lavender `#B8A1FF` | ink `#14163A` | 7.95:1 | pass |
| hib_light `#FF7FA8` | ink `#14163A` | 7.34:1 | pass |
| sky `#7FE3D8` | ink `#14163A` | 11.51:1 | pass |
| hib_light `#FF7FA8` | navy `#1B1F4B` | 6.59:1 | pass |
| teal `#19C3B1` | navy `#1B1F4B` | 7.05:1 | pass |
| yellow `#FFD23F` | navy `#1B1F4B` | 10.82:1 | pass |
| lavender `#B8A1FF` | navy `#1B1F4B` | 7.13:1 | pass |
| cream `#FFF4E0` | night_hi `#252A63` | 12.12:1 | pass |
| yellow `#FFD23F` | night_hi `#252A63` | 9.15:1 | pass |
| hib_light `#FF7FA8` | night_hi `#252A63` | 5.57:1 | pass |
| teal `#19C3B1` | night_hi `#252A63` | 5.96:1 | pass |
| lavender `#B8A1FF` | night_hi `#252A63` | 6.03:1 | pass |
| sky `#7FE3D8` | night_hi `#252A63` | 8.73:1 | pass |
| night_muted `#A9A8D6` | night_hi `#252A63` | 5.82:1 | pass |
| ink `#14163A` | yellow `#FFD23F` | 12.06:1 | pass |
| ink `#14163A` | teal `#19C3B1` | 7.87:1 | pass |
| cream `#FFF4E0` | hibiscus `#D81B60` | 4.54:1 | pass |
| ink `#14163A` | lavender `#B8A1FF` | 7.95:1 | pass |
| ink `#14163A` | cream `#FFF4E0` | 15.98:1 | pass |
| ink `#14163A` | day_side `#F6E6C8` | 14.16:1 | pass |
| ink `#14163A` | day_hi `#EBD7B0` | 12.34:1 | pass |
| hibiscus `#D81B60` | cream `#FFF4E0` | 4.54:1 | pass |
| day_muted `#4E5180` | cream `#FFF4E0` | 6.85:1 | pass |
| day_muted `#4E5180` | day_side `#F6E6C8` | 6.07:1 | pass |
| day_muted `#4E5180` | day_hi `#EBD7B0` | 5.29:1 | pass |
| day_teal `#0A6B63` | cream `#FFF4E0` | 5.85:1 | pass |
| day_violet `#5B3FB8` | cream `#FFF4E0` | 6.77:1 | pass |
| day_gold `#7D4A00` | cream `#FFF4E0` | 6.76:1 | pass |
| day_blue `#0B5F8C` | cream `#FFF4E0` | 6.36:1 | pass |
| day_green `#1B6B3A` | cream `#FFF4E0` | 6.00:1 | pass |
| day_teal `#0A6B63` | day_hi `#EBD7B0` | 4.51:1 | pass |
| day_violet `#5B3FB8` | day_hi `#EBD7B0` | 5.22:1 | pass |
| day_gold `#7D4A00` | day_hi `#EBD7B0` | 5.22:1 | pass |
| day_blue `#0B5F8C` | day_hi `#EBD7B0` | 4.91:1 | pass |
| day_green `#1B6B3A` | day_hi `#EBD7B0` | 4.63:1 | pass |
| day_hib `#B5124F` | day_hi `#EBD7B0` | 4.70:1 | pass |
| day_hib `#B5124F` | day_side `#F6E6C8` | 5.40:1 | pass |
| day_hib `#B5124F` | cream `#FFF4E0` | 6.09:1 | pass |
| day_teal `#0A6B63` | day_side `#F6E6C8` | 5.18:1 | pass |
| day_violet `#5B3FB8` | day_side `#F6E6C8` | 5.99:1 | pass |
| day_gold `#7D4A00` | day_side `#F6E6C8` | 5.99:1 | pass |
| day_blue `#0B5F8C` | day_side `#F6E6C8` | 5.63:1 | pass |
| day_green `#1B6B3A` | day_side `#F6E6C8` | 5.32:1 | pass |
| cream `#FFF4E0` | hibiscus `#D81B60` | 4.54:1 | pass |
| cream `#FFF4E0` | day_violet `#5B3FB8` | 6.77:1 | pass |
| cream `#FFF4E0` | day_teal `#0A6B63` | 5.85:1 | pass |
| cream `#FFF4E0` | ink `#14163A` | 15.98:1 | pass |

Derived shades (`night_hi`, `hib_light`, `day_*`, `mint`, `blue_dk`) exist only to keep text at 4.5:1 or better.
