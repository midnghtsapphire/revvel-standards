Hula Arcade Night (free) by AudreyBuildsAI

1. Open VS Code or Cursor, Extensions view, "..." menu, Install from VSIX..., pick hula-arcade-night-1.0.0.vsix.
2. Press Ctrl+K Ctrl+T (Cmd+K Cmd+T on a Mac) and choose "Hula Arcade Night".

Every text color clears WCAG AA contrast (4.5:1). MIT licensed, see LICENSE.txt.
Want the light theme "Aloha Day", the Windows Terminal scheme, the Starship preset, and the oh-my-posh themes? They are in the Pro bundle from AudreyBuildsAI.
Not affiliated with Microsoft or GitHub.
