<!-- Hula Arcade README Kit, Layout 02: Aloha Minimal.  Search this file for "EDIT" and swap in your own words. -->

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/banners/banner-minimal-dark.svg">
  <img alt="Aloha! This is my corner of the internet." src="assets/banners/banner-minimal-light.svg" width="100%">
</picture>

<!-- EDIT: a short, warm intro -->
Hi, I'm **YOUR NAME**. I make YOUR THING. Come say aloha.

> [!NOTE]
> EDIT: one sentence about what you are working on right now.

### What I use

<img alt="Python" src="assets/badges/skill-python.svg" height="28"> <img alt="Typescript" src="assets/badges/skill-typescript.svg" height="28"> <img alt="Javascript" src="assets/badges/skill-javascript.svg" height="28"> <img alt="Rust" src="assets/badges/skill-rust.svg" height="28"> <img alt="Go" src="assets/badges/skill-go.svg" height="28"> <img alt="React" src="assets/badges/skill-react.svg" height="28">

### Say hello

- EDIT: [your website](https://example.com)
- EDIT: [your email](mailto:you@example.com)

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/dividers/divider-wave-dark.svg">
  <img alt="" src="assets/dividers/divider-wave-light.svg" width="100%">
</picture>
