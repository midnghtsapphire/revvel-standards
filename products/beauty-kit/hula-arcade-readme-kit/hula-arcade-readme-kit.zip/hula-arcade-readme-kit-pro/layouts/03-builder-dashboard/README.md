<!-- Hula Arcade README Kit, Layout 03: Builder Dashboard.  Search this file for "EDIT". Replace YOUR-USERNAME (3 places). -->

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/banners/banner-dashboard-dark.svg">
  <img alt="Build log. Ship, learn, repeat." src="assets/banners/banner-dashboard-light.svg" width="100%">
</picture>

<!-- EDIT: who you are, in one line -->
**YOUR NAME** builds YOUR THING in public. This page is my scoreboard.

### Scoreboard

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/stats-dark.svg">
  <img alt="My public GitHub stats: stars, repositories, followers, and top languages" src="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/stats-light.svg" width="100%">
</picture>

<!-- OPTIONAL: richer card from the metrics workflow (see SETUP-GUIDE). Remove the comment markers once metrics.yml has run once.
<img alt="Detailed GitHub metrics" src="assets/generated/metrics.svg" width="100%">
-->

### Featured projects

| Project | What it does | Status |
|---|---|---|
| [project-one](https://github.com/YOUR-USERNAME/project-one) | EDIT: one line | <img alt="Shipping" src="assets/badges/status-shipping.svg" height="28"> |
| [project-two](https://github.com/YOUR-USERNAME/project-two) | EDIT: one line | <img alt="Building in public" src="assets/badges/status-building-in-public.svg" height="28"> |
| [project-three](https://github.com/YOUR-USERNAME/project-three) | EDIT: one line | <img alt="Learning" src="assets/badges/status-learning.svg" height="28"> |

### How I work

```mermaid
flowchart LR
    A[Idea] --> B[Prototype]
    B --> C[Ship]
    C --> D[Learn]
    D --> A
```

<details>
<summary><b>Toolbox</b></summary>

<img alt="Python" src="assets/badges/skill-python.svg" height="28"> <img alt="Typescript" src="assets/badges/skill-typescript.svg" height="28"> <img alt="Javascript" src="assets/badges/skill-javascript.svg" height="28"> <img alt="Rust" src="assets/badges/skill-rust.svg" height="28"> <img alt="Go" src="assets/badges/skill-go.svg" height="28"> <img alt="React" src="assets/badges/skill-react.svg" height="28"> <img alt="Node" src="assets/badges/skill-node.svg" height="28"> <img alt="Docker" src="assets/badges/skill-docker.svg" height="28"> <img alt="Sql" src="assets/badges/skill-sql.svg" height="28"> <img alt="Linux" src="assets/badges/skill-linux.svg" height="28">

</details>

<details>
<summary><b>Contribution snake</b></summary>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/snake-dark.svg">
  <img alt="A snake eating my contribution graph" src="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/snake.svg" width="100%">
</picture>

</details>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/dividers/divider-pellets-dark.svg">
  <img alt="" src="assets/dividers/divider-pellets-light.svg" width="100%">
</picture>

<!-- EDIT: links -->
[GitHub](https://github.com/YOUR-USERNAME) | [Website](https://example.com) | [Email](mailto:you@example.com)
