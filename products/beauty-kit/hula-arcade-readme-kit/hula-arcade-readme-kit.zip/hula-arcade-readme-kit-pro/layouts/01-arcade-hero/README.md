<!-- Hula Arcade README Kit, Layout 01: Arcade Hero.  Search this file for "EDIT" and swap in your own words.
     Also replace YOUR-USERNAME (3 places below) with your GitHub username. -->

<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/banners/banner-hero-dark.svg">
  <img alt="Aloha, world! Shipping with aloha, one pellet at a time." src="assets/banners/banner-hero-light.svg" width="100%">
</picture>

<!-- EDIT: your name and one-line pitch -->
## Hi, I'm YOUR NAME

**I build YOUR THING and I love YOUR OTHER THING.**

<img alt="Building In Public" src="assets/badges/status-building-in-public.svg" height="28"> <img alt="Open To Collab" src="assets/badges/status-open-to-collab.svg" height="28"> <img alt="Learning" src="assets/badges/status-learning.svg" height="28">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/dividers/divider-pellets-dark.svg">
  <img alt="" src="assets/dividers/divider-pellets-light.svg" width="100%">
</picture>

</div>

### About me

| | |
|---|---|
| **Now building** | EDIT: the project you are into this month |
| **Now learning** | EDIT: a language, tool, or skill |
| **Ask me about** | EDIT: three topics you enjoy |
| **Fun fact** | EDIT: something that makes people smile |

> [!TIP]
> EDIT: a friendly note, like how you like to collaborate or the best way to reach you.

### Toolbox

<img alt="Python" src="assets/badges/skill-python.svg" height="28"> <img alt="Typescript" src="assets/badges/skill-typescript.svg" height="28"> <img alt="Javascript" src="assets/badges/skill-javascript.svg" height="28"> <img alt="Rust" src="assets/badges/skill-rust.svg" height="28"> <img alt="Go" src="assets/badges/skill-go.svg" height="28"> <img alt="React" src="assets/badges/skill-react.svg" height="28"> <img alt="Node" src="assets/badges/skill-node.svg" height="28"> <img alt="Docker" src="assets/badges/skill-docker.svg" height="28">

<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/dividers/divider-wave-dark.svg">
  <img alt="" src="assets/dividers/divider-wave-light.svg" width="100%">
</picture>

### Contribution snake

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/snake-dark.svg">
  <img alt="A snake eating my contribution graph" src="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/snake.svg" width="100%">
</picture>

### Pixel stats

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/stats-dark.svg">
  <img alt="My public GitHub stats: stars, repositories, followers, and top languages" src="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/stats-light.svg" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/dividers/divider-pellets-dark.svg">
  <img alt="" src="assets/dividers/divider-pellets-light.svg" width="100%">
</picture>

<!-- EDIT: links. Keep only the ones you use. Plain links, no trackers. -->
[GitHub](https://github.com/YOUR-USERNAME) &nbsp;|&nbsp; [Website](https://example.com) &nbsp;|&nbsp; [Email](mailto:you@example.com)

</div>
